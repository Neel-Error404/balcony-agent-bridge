# Release Checklist

Use this checklist in order. Keep outputs small and evidence-driven.

## Repo And Branch

1. Record current branch and target SHA.
2. Check whether the worktree is dirty.
3. Confirm whether deployment target is preview or production.
4. Classify the release mode:
   - `frontend-only`
   - `backend-only`
   - `both-compatible`
   - `both-breaking`
5. If both surfaces changed, decide whether the backend contract is additive or breaking before any deploy.

Suggested commands:
```powershell
git status --short
git branch --show-current
git rev-parse HEAD
```

## Frontend Verification

Run from `frontend/` if that is where the package scripts live.

```powershell
npm run lint
npm run build
```

If tests exist and are installed:
```powershell
npm test
```

## Backend Verification

If Python and test tooling are available:
```powershell
pytest -q
```

If the environment cannot run backend tests, record that as missing evidence.

## Product Smoke Checks

Check these flows explicitly:

1. Template selection
2. Question review before publish
3. Explicit publish
4. Share-link respondent flow
5. Admin flow for admin and non-admin users

Expected model:
- browsing templates may be public
- creator actions require login
- anonymous response happens through `/respond/<code>`
- distribution works on existing surveys, not raw templates

## Security Checks

Inspect these endpoints when touched:

1. `POST /api/templates`
2. `POST /api/templates/generate`
3. `POST /api/surveys`
4. `POST /api/surveys/{survey_id}/publish`
5. `POST /api/surveys/{survey_id}/links`
6. `/api/admin/*`

Questions to answer:
- is auth required where it should be?
- is role enforcement required and present?
- does the frontend imply stronger controls than the backend actually has?

Deployment-specific checks:
- Is `JWT_SECRET_KEY` present in the live backend environment?
- Is the backend using `CORS_ALLOW_ORIGINS` as the canonical allowlist?
- Does the allowlist include only exact intended frontend origins?
- Are preview checks using a stable hostname already present in that allowlist?
- Are browser-safe frontend vars limited to `NEXT_PUBLIC_*` values that are genuinely public?
- Are secret-bearing settings stored in protected environment/app settings or a secret manager?

## Backend Deployment

Use the repo-root GitHub Actions workflow:
- `D:/Work_Projects/agentic_azure/.github/workflows/azure-deploy-backend.yml`

Sequence guidance:
- `backend-only`: deploy backend, verify health, then smoke the existing frontend against it.
- `both-compatible`: deploy backend before frontend.
- `both-breaking`: stop and require a compatibility plan, slot strategy, or feature flag rollout.

Capture:
- workflow run ID
- deployment result
- Azure backend URL

Required health checks:
```text
GET /health/live => 200
GET /health/ready => 200
```

Also verify when possible:
```text
Azure App Service httpsOnly => true
Azure startup command uses uvicorn.workers.UvicornWorker
Azure healthCheckPath matches the intended readiness route
```

## Frontend Deployment

Sequence guidance:
- `frontend-only`: preview first, then smoke, then promote.
- When backend CORS uses exact origins, validate against a stable preview alias instead of an ephemeral deployment hostname.

Capture:
- Vercel deployment ID
- production URL
- commit SHA served

Required check:
- production URL returns `200`

## Final Decision

Use one of:
- `ready`
- `ready with explicit risk`
- `not ready`

Always include:
- deployed SHA
- tested flows
- untested areas
- any blockers or rollback concerns
