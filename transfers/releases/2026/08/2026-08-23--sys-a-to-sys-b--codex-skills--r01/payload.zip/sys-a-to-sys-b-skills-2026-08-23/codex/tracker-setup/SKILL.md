---
name: tracker-setup
description: Use when connecting Linear or Jira as Symphony's control surface and validating that tracker issues can drive repo-local work correctly.
---

# Tracker Setup

## Purpose

This skill defines how to connect Symphony to a tracker and how to validate that the tracker can actually serve as the control surface.

Supported default shapes:
- Linear project -> repo
- Jira project/board -> repo

## Core Principle

The tracker is the interface for execution.

That means Symphony should be able to:
- read eligible issues
- claim or lock work
- understand ticket scope
- post plan/progress back
- surface PR/review linkage
- resume on rework

If that loop does not work, Symphony is not really set up yet.

## When To Use

- connecting Linear to a repo-local Symphony setup
- connecting Jira to a repo-local Symphony setup
- validating MCP/API access for tracker operations
- deciding whether one tracker project should map to one repo or many repos

## Preferred Mapping

Default mapping:
- one tracker project/board -> one repo -> one repo-local `WORKFLOW.md`

Avoid many unrelated repos behind one tracker control surface until the single-repo flow is proven.

## Connection Strategy

Prefer the official integration path first:
- official MCP server if available in the environment
- otherwise official API/CLI path

Do not claim tracker setup is complete until read and write operations are validated.

## Minimum Validation Loop

Prove all of these:
1. list/open candidate issues
2. fetch one issue with full description/comments
3. write back a planning comment or equivalent note
4. move or update state in a controlled test flow
5. confirm Symphony can map that issue to the intended repo/workspace

## Ticket Design Rules

Tickets should be scoped so one worker can usually produce one reviewable PR.

Require:
- clear objective
- acceptance criteria
- repo or component scope
- blockers/dependencies where relevant

## Workflow Design Guidance

Do not create one tracker workflow step per internal agent thought.

Instead:
- keep tracker states human-meaningful
- keep internal worker behavior inside `WORKFLOW.md`

Good tracker states:
- Backlog
- Todo
- In Progress
- In Review
- Rework
- Done

Internal agent stages like research, implementation, testing, and validation usually belong in `WORKFLOW.md`, not as separate tracker-state machinery.

## Deliverable

When using this skill, produce:

```text
Tracker Connection Decision
- tracker:
- integration_path:
- project_to_repo_mapping:
- required_permissions:
- validation_loop:
```

Then produce:

```text
Tracker Validation Result
- can_read_issues:
- can_write_updates:
- can_move_state:
- can_link_execution_to_repo:
- blockers:
```

## Safety Rules

- Do not assume tracker auth works without a real read/write test.
- Do not map one tracker project to many repos unless routing is explicit and proven.
- Do not overload the tracker with internal orchestration detail that belongs in `WORKFLOW.md`.
