---
name: linear
description: Linear project management for SurveyAI on VoiceAI Platform. Use when mentioning "Linear", "ticket", "issue", "create task", "check tickets", "update status", or working with the Algo_mod/SurveyAI workspace. Handles ticket listing, reading, creating, and updating with focus on agent-friendly Symphony execution.
---

# Linear

Linear project management integration for the SurveyAI project within the VoiceAI Platform.

## When to Use This Skill

Activate this skill when:
- User mentions "Linear", "check tickets", "list issues"
- User wants to "create a task", "make a ticket", "update status"
- User asks about "Symphony tickets", "backlog", "project status"
- User needs to understand the ticket reuse strategy
- User is working on a task that should be tracked in Linear
- User wants to batch or orchestrate multiple Symphony-ready tickets, in which case also use `symphony-controller`

## Configuration

| Setting | Value |
|---------|-------|
| **Workspace** | `Algo_mod` |
| **Team** | `Algo_mod` (ID: `6112d8fa-b9c3-4f12-97f0-9a86d4501d72`) |
| **Project** | `SurveyAI` |
| **Team Key** | `ALG` |
| **Ticket Limit** | 250 total (use reuse strategy!) |

## Available MCP Tools

The Linear MCP server provides these tools (all prefixed with `mcp__plugin_linear_linear_`):

| Tool | Purpose | Read/Write |
|------|---------|------------|
| `list_teams` | List all teams | Read |
| `list_issues` | List/filter issues | Read |
| `get_issue` | Get issue details | Read |
| `save_issue` | Create or update issue | Write |
| `list_projects` | List projects | Read |
| `get_project` | Get project details | Read |
| `list_comments` | List issue comments | Read |
| `save_comment` | Create or update comment | Write |
| `save_status_update` | Create project status update | Write |

## Ticket Reuse Strategy

**CRITICAL**: Linear has a 250-ticket limit. Always prefer updating existing tickets over creating new ones.

### Decision Tree

```
Can existing ticket be updated?
├── YES → Add comment/child ticket, update description
└── NO
    ├── Is this a subtask of existing work?
    │   ├── YES → Add as child issue or comment
    │   └── NO → Create new ticket (document justification)
```

### When to Update vs Create

| Situation | Action |
|-----------|--------|
| Bug in existing feature | Update the original feature ticket |
| Follow-up to completed work | Reopen original ticket with new comment |
| Subtask of larger epic | Add as child issue or comment |
| Truly new feature area | Create new ticket (justify in description) |
| Deployment issue | Update deployment-change ticket or create if none exists |

## Symphony-Ready Ticket Structure

Tickets meant for Symphony execution should follow this structure:

### Template Fields

```markdown
## [{Component}] {Title}

**Context:** {What happened, when, symptoms - keep it factual}

**Acceptance:**
- [ ] {Specific, testable criterion 1}
- [ ] {Specific, testable criterion 2}
- [ ] {Evidence captured in founder logs}

**Validation:**
```bash
# Mode-specific validation commands from WORKFLOW.md
```

**Evidence:** `founder_logs/SESSION_YYYY-MM-DD/validation_evidence/{file}.md`
```

### Component Tags

| Tag | Workflow Mode | When to Use |
|-----|---------------|-------------|
| `[Voice]` | `voice-incident` | Voice regressions, websocket, transcript issues |
| `[Backend]` | `backend-feature` | API changes, orchestration, persistence |
| `[Frontend]` | `frontend-feature` | Dashboard, UI, analytics views |
| `[Deployment]` | `deployment-change` | Azure settings, GitHub Actions, env changes |
| `[Workflow]` | `workflow-authoring` | Flow YAML, branching rules, orchestration schemas |

### Symphony-Ready Label

Tickets ready for Symphony agent execution should have the `Symphony-ready` label. This means:
- Clear acceptance criteria
- Validation commands specified
- Evidence path defined
- Component scope identified

## Workflow Modes Mapping

Each ticket type maps to a workflow mode defined in `WORKFLOW.md`:

| Ticket Tag | Workflow Mode | Required Validation |
|------------|---------------|---------------------|
| `[Voice]` | `voice-incident` | Voice transcript, beta gate, websocket tests |
| `[Backend]` | `backend-feature` | Backend tests, API contract parity |
| `[Frontend]` | `frontend-feature` | Lint, build, browser QA |
| `[Deployment]` | `deployment-change` | Health checks, deployment validation |
| `[Workflow]` | `workflow-authoring` | Workflow execution tests |

See `WORKFLOW.md` for detailed mode-specific instructions.

## Common Operations

### List Issues

```bash
# List all issues in SurveyAI project
mcp__plugin_linear_linear__list_issues(
    team="Algo_mod",
    project="SurveyAI",
    limit=50
)

# Filter by status
mcp__plugin_linear_linear__list_issues(
    team="Algo_mod",
    state="Backlog"
)

# Filter by label
mcp__plugin_linear_linear__list_issues(
    team="Algo_mod",
    label="Symphony-ready"
)
```

### Get Issue Details

```bash
mcp__plugin_linear_linear__get_issue(
    id="ALG-5",
    includeRelations=true
)
```

### Create New Ticket

```bash
mcp__plugin_linear_linear__save_issue(
    title="Fix voice websocket timeout",
    description="## [Voice] WebSocket timeout on long surveys\n\n**Context:**\nWebSocket connections timeout after 2 minutes during long voice surveys.\n\n**Acceptance:**\n- [ ] WebSocket stays alive for 5+ minute surveys\n- [ ] No transcript gaps on long surveys\n\n**Validation:**\n```bash\ncd backend && pytest -q tests/e2e/test_voice_agent_websocket.py\n```\n\n**Evidence:** `founder_logs/SESSION_2026-03-17/validation_evidence/websocket_timeout_fix.md`",
    team="Algo_mod",
    project="SurveyAI",
    labels=["Symphony-ready"],
    state="Backlog"
)
```

### Update Existing Ticket

```bash
mcp__plugin_linear_linear__save_issue(
    id="ALG-5",
    description="Updated description with new acceptance criteria"
)
```

### Add Comment to Ticket

```bash
mcp__plugin_linear_linear__save_comment(
    issueId="ALG-5",
    body="Progress update: Investigating VAD activation timing. See founder_logs/SESSION_2026-03-17/gap_analysis/ for details."
)
```

## State Management

Use human-meaningful states from `WORKFLOW.md`:

| State | When to Use |
|-------|-------------|
| `Backlog` | Approved but not scheduled |
| `Todo` | Scheduled, ready to start |
| `In Progress` | Active work |
| `In Review` | PR open, validation passed |
| `Rework` | Review feedback, needs fixes |
| `Done` | Merged, evidence captured |

Do NOT mirror internal steps (research, coding, testing) into tracker state.

## Integration with WORKFLOW.md

Linear tickets are the control surface; `WORKFLOW.md` is the execution contract.

1. **Before starting work**: Read the ticket, identify the component tag
2. **Choose mode**: Map component to workflow mode (e.g., `[Voice]` → `voice-incident`)
3. **Follow mode**: Run mode-specific validation from `WORKFLOW.md`
4. **Update ticket**: Post plan, status, validation summary, PR link
5. **Close ticket**: Only after merge + founder evidence

## Founder Log Protocol

Per `WORKFLOW.md`, all nontrivial work must:
- Create/update `founder_logs/SESSION_YYYY-MM-DD/SESSION_SUMMARY.md`
- Store evidence in `founder_logs/SESSION_YYYY-MM-DD/validation_evidence/`
- Use `gap_analysis/` for unresolved risks

Lack of evidence = incomplete ticket.

## Documentation References

| Document | Purpose |
|----------|---------|
| `WORKFLOW.md` | Execution modes, validation commands |
| `docs/LINEAR_TICKET_STRATEGY.md` | Full ticket templates and examples |
| `founder_logs/CONTEXT_INDEX.md` | Operational truth reference |
| `docs/SYMPHONY_SETUP.md` | Symphony-Lyra integration |

## Example Ticket Creation

**User:** "Create a ticket for fixing the voice websocket timeout issue"

**Response:**
```
📋 Creating Linear ticket for SurveyAI...

Checking for existing related tickets...
- ALG-5: "VAD activation and end to end survey" (similar scope)
- Checking if this should be an update...

Decision: This is a specific sub-issue of ALG-5. Adding as comment instead.

Comment added to ALG-5:
"Sub-issue: WebSocket timeouts after 2 minutes on long surveys. Need to keep connection alive for 5+ minute surveys with full transcript persistence."

Alternative: If you want a separate focused ticket, I can create ALG-6 with title "[Voice] Fix websocket timeout on long surveys" and link as blocker/related to ALG-5.

Which approach do you prefer?
```
