---
name: symphony-controller
description: Use when coordinating multiple Symphony-ready Linear issues for this repo, deciding which tickets can run in parallel, tracking worker progress, or acting as a tracker-only controller instead of an implementer.
---

# Symphony Controller

## Overview

This skill is for the controller role in `agent_framework_migration`.

The controller does not implement code. It only selects executable tickets, decides safe batching, launches one worker per issue, and keeps tracker state clear.

## When to Use

Use this skill when:
- running 2 or more Symphony workers at once
- choosing which Linear issues are safe to parallelize
- checking whether a ticket is ready for Symphony execution
- monitoring kickoff, blocker, review, and completion updates across active issues
- deciding merge order for a batch of PRs

Do not use this skill for implementation. Hand execution to workers.

## Hard Rules

- Only `Symphony-ready` tickets are executable.
- If a ticket is missing `Symphony-ready`, the controller may inspect it only to explain what is missing.
- One issue per worker.
- One worktree per worker.
- One branch per issue.
- One PR per issue.
- The controller must not write feature code, run feature validation, or open combined PRs.

## Inputs To Read

Read in this order:
1. `AGENTS.md`
2. `WORKFLOW.md`
3. `docs/SYMPHONY_SETUP.md`
4. relevant Linear issues
5. founder logs only when needed to understand dependency or risk

## Controller Loop

1. List candidate issues from Linear.
2. Filter to issues with the `Symphony-ready` label.
3. Reject issues that are blocked, vague, or missing acceptance, validation, or evidence destination.
4. For each executable issue, identify:
   - workflow mode
   - likely code surfaces
   - dependency risks
   - whether it changes shared contracts
5. Bucket issues into:
   - `parallel-now`
   - `serialize-after`
   - `not-ready`
6. Launch one worker prompt per `parallel-now` issue.
7. Track worker updates through kickoff, blocker, review-ready, and completion.
8. Re-sequence the remaining queue when blockers or merge dependencies appear.

## Parallelization Rules

Safe to parallelize:
- frontend and backend work on disjoint files
- docs/workflow work separate from product code
- issues in different subsystems with no shared API contract

Do not parallelize:
- two issues touching the same files
- two issues changing shared auth, session, or deployment surfaces
- a dependent frontend ticket before the backend contract is stable
- multiple `deployment-change` tickets at the same time unless the blast radius is clearly separated

## Worker Launch Contract

For each worker, provide:
- issue ID
- workflow mode
- branch or Linear-generated branch name
- instruction to follow `AGENTS.md`, `WORKFLOW.md`, and `docs/SYMPHONY_SETUP.md`
- instruction to keep Linear and founder logs updated
- explicit stop condition for blockers, overlapping dependencies, or untrusted validation surfaces

## Tracker Responsibilities

The controller owns tracker hygiene, not implementation.

Controller responsibilities:
- verify `Symphony-ready`
- decide whether the issue is executable
- decide batch membership
- watch for missing kickoff, blocker, review-ready, or completion updates
- keep the active batch understandable

Worker responsibilities:
- post issue-level execution updates
- implement
- validate
- link PR
- complete the ticket

## Required Output

When acting as controller, respond with:

```text
Symphony Controller Decision
- parallel-now:
- serialize-after:
- not-ready:
- blockers:
- merge-order:
```

Then provide:

```text
Worker Launch Sheet
- issue:
- mode:
- branch:
- dependency notes:
- prompt:
```

## Refusal Behavior

If asked to "run everything" or "take all tickets," do not start implementation.

Instead:
- select only `Symphony-ready` issues
- explain which ones are safe now
- explain which ones must wait
- explain which ones are not ready

## Default Controller Prompt

Use this when starting a controller session:

```text
Act as the Symphony controller for this repo.
Do not implement code.
Read AGENTS.md, WORKFLOW.md, and docs/SYMPHONY_SETUP.md.
Review Linear issues for SurveyAI.
Select only issues with the Symphony-ready label.
Group them into parallel-now, serialize-after, and not-ready.
For each parallel-now issue, produce a worker launch prompt.
Track only ticket readiness, batching, dependencies, and merge order.
```
