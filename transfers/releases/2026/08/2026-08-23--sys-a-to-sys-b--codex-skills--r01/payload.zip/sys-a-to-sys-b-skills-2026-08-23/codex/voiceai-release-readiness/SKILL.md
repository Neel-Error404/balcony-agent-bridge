---
name: voiceai-release-readiness
description: Use when deploying, validating, or giving go/no-go release advice for the VoiceAI or SurveyAI platform in the agent_framework_migration repo. Covers local verification, auth-flow smoke checks, Azure backend health, Vercel frontend health, and release evidence capture.
---

# VoiceAI Release Readiness

Use this skill for this repo when the task is to deploy, verify deployment quality, or decide whether the system is ready to release.

## Scope

This skill is for the combined release path:
- Next.js frontend on Vercel
- FastAPI backend on Azure App Service
- GitHub Actions backend deployment via the repo-root workflow
- survey creator, distribution, respondent, and admin flows

Release modes this skill must distinguish explicitly:
- `frontend-only`
- `backend-only`
- `both-compatible`
- `both-breaking`

Read [references/checklist.md](references/checklist.md) before acting.

## Workflow

### 1. Confirm release intent first

Before deploying, identify:
- target branch
- target commit SHA
- whether the user wants preview or production
- whether backend, frontend, or both are changing
- whether the backend change is additive/backward-compatible or breaking
- whether the frontend depends on a new backend contract
- whether the worktree contains unrelated dirty changes that reduce release confidence

If branch state is ambiguous or the worktree is dirty in a way that affects release confidence, say so before proceeding.

For this repo, branch intent should normally resolve to:
- `main` = sacred production truth
- `develop` = integration branch and preview validation gate

Frontend release governance for this repo:
- non-production frontend validation should land on `develop` first
- Vercel preview validation should happen from `develop` or from PRs targeting `develop`
- `main` should only receive changes that already passed preview validation
- production frontend promotion should happen only from `main`
- do not treat an ad hoc local `vercel deploy --prod` from a dirty workspace as the normal release path when Git integration is healthy

If `master` still appears in deploy history or old automation, treat that as migration residue, not as a second valid production branch.

### 2. Verify local readiness before any deploy

Run only the checks relevant to the changed surface.

Minimum frontend checks:
- `npm run lint`
- `npm run build`

Minimum backend checks if Python and test tooling are available:
- targeted `pytest` for touched areas, or `pytest -q`

If a test environment is unavailable, record that clearly as missing evidence. Do not silently skip it.

### 3. Verify product-critical flows, not just builds

Always test the release against the intended product model:
- template selection leads to the correct creator flow
- question review is visible before publish
- publish is explicit
- anonymous response only works through share links
- admin pages require admin, not just login

If the app's route model is the thing under review, inspect frontend routes and backend auth dependencies together before shipping.

### 4. Verify security-sensitive endpoints

For this repo, always inspect these areas before release when touched:
- template publishing and template generation endpoints
- survey create, publish, and link creation endpoints
- admin endpoints and admin page gating
- any endpoint that uses optional auth instead of required auth

Treat CORS as transport policy, not authorization.

### 5. Deploy from the real source of truth

For backend deploys, use the repo-root workflow:
- `D:/Work_Projects/agentic_azure/.github/workflows/azure-deploy-backend.yml`

Do not rely on stale nested workflows or undocumented manual steps unless there is a verified emergency reason.

For frontend deploys, verify the intended Vercel target and that production points to the intended commit.

For this repo, the minimum control-plane alignment is:
- GitHub default branch is `main`
- backend production workflow triggers from `main`
- Vercel project `link.productionBranch` is `main`

If any one of those is false, do not describe the release model as "merge to main deploys production cleanly."

### 5.5 Choose the deployment sequence by change class

Use this matrix instead of defaulting to "deploy everything":

`frontend-only`
- Push or merge to `develop` first when following the normal branch-gated flow.
- Validate the Vercel preview produced from that Git state before touching `main`.
- Use a stable preview hostname or branch alias when backend CORS is origin-based.
- Smoke the preview against the current production backend.
- Merge `develop` to `main` only after preview passes.
- Promote frontend production only from `main`.
- Do not redeploy backend unless a verified integration issue requires it.
- If the production deployment was promoted manually through the CLI, explicitly verify that Vercel's Git link still reports `productionBranch: main` before calling the branch automation healthy.

`backend-only`
- Verify backend tests and deployment configuration first.
- Confirm required Azure app settings are present before deploy, especially:
  - `JWT_SECRET_KEY`
  - `CORS_ALLOW_ORIGINS`
  - auth provider settings
  - Azure OpenAI settings
- Deploy backend first through the repo-root workflow.
- Verify Azure runtime health and then smoke the existing frontend against the new backend.
- Do not redeploy frontend unless the backend change requires a coordinated UI change.

`both-compatible`
- Prefer backend first, then frontend.
- Reason: an additive backend usually preserves old frontend behavior, while a new frontend often assumes backend fields or endpoints that the old backend may not yet serve.
- Sequence:
  1. verify both surfaces locally,
  2. deploy backend,
  3. verify `/health/live` and `/health/ready`,
  4. smoke key creator/respondent/admin flows against the deployed backend,
  5. land frontend changes on `develop`,
  6. validate the Vercel preview from `develop` against the deployed backend,
  7. merge `develop` to `main`,
  8. promote frontend production from `main`.

`both-breaking`
- Do not do a simple sequential production deploy.
- Require at least one of:
  - temporary backward compatibility in the backend,
  - feature flags,
  - deployment slots / blue-green cutover,
  - a versioned API contract.
- If none of those exist, the correct decision is to stop and redesign the release plan before shipping.

### 5.6 Security release gates

Before calling a release safe enough to ship, explicitly verify:
- `JWT_SECRET_KEY` exists in the live backend environment and is not relying on a code fallback.
- `CORS_ALLOW_ORIGINS` is the canonical backend allowlist and contains only exact expected origins.
- preview validation uses a stable hostname already present in `CORS_ALLOW_ORIGINS`.
- `NEXT_PUBLIC_*` variables expose only public browser-safe values.
- secret-bearing settings such as API keys and signing keys are stored in a secret manager or equivalent protected app settings, not committed files.
- Azure App Service is still `httpsOnly=true`.
- backend startup still uses the ASGI worker contract.

When checking live settings, capture presence and safety properties without printing secret values.

### 6. Verify runtime health after deploy

Minimum backend runtime checks:
- Azure app reports healthy deployment
- `/health/live` returns `200`
- `/health/ready` returns `200`
- Azure App Service configuration still reports the expected startup command and health check path when those are part of the release contract

Minimum frontend runtime checks:
- production URL returns `200`
- the app is serving the intended commit or deployment
- Vercel project metadata still exposes the expected repo link and `productionBranch`

Minimum product smoke:
- authenticated creator flow works
- respondent share-link flow works
- admin flow behaves correctly for both admin and non-admin users

### 7. Produce a go/no-go decision with evidence

Always report:
- commit SHA deployed
- workflow run ID or deployment ID
- exact health-check results
- which flows were actually tested
- what was not tested
- whether the release mode was `frontend-only`, `backend-only`, `both-compatible`, or `both-breaking`
- whether secrets and exact-origin config were verified in the live target
- whether the system is `ready`, `ready with explicit risk`, or `not ready`

Never collapse "build passed" into "system ready" without runtime and flow checks.

## Stop Conditions

Do not call the system ready if any of these are true:
- backend health endpoints are failing
- frontend production points to the wrong commit
- Vercel frontend production branch metadata is missing or does not match the intended truth branch
- creator flow and respondent flow are crossing incorrectly
- publish/share controls are implicit or bypassable in the changed area
- required tests failed
- required tests could not run and the missing evidence is material
- backend is relying on fallback auth secrets or unverified secret injection
- preview validation depends on an ephemeral hostname that is not in the backend CORS allowlist
- the deployment requires a breaking frontend/backend cutover but no compatibility strategy exists

## Vercel CLI Notes For This Repo

Use these checks when frontend branch ownership is unclear:

```bash
gh repo view Neel-Error404/Survey_AI --json defaultBranchRef
vercel api /v9/projects/<projectId> --scope <scope> --raw
vercel api "/v6/deployments?projectId=<projectId>&limit=5&state=READY" --scope <scope> --raw
```

Interpretation rules:
- a live production deployment sourced from `cli` means the site is live, but it does not by itself prove that future Git pushes will promote production correctly
- the last Git deployment metadata can reveal stale branch ownership, for example `githubCommitRef: master`
- the source-of-truth branch mapping is the project `link.productionBranch`
- for this repo, the expected steady-state is `develop` for preview validation and `main` for production promotion

Local CLI hygiene for this repo:
- if Git integration is the intended deployment gate, unlink the local workspace from Vercel CLI when that local link encourages bypassing the branch model
- prefer Git-driven preview deployments over repo-root CLI deploys from a dirty workspace
- if local CLI deploys are temporarily needed for debugging, treat them as exceptions and do not confuse them with the official release path

If the project is linked to the right repo but the branch mapping is stale or missing, repair it with:

```bash
vercel git connect https://github.com/Neel-Error404/Survey_AI.git --scope <scope>
```

If Vercel cannot infer Git metadata from the current checkout because the repo is being accessed through a worktree path, either:
- pass the repo URL explicitly as above, or
- run the command from the Git repo root instead of the worktree path
