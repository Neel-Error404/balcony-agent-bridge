---
name: stay-on-track
description: Keep complex Codex work bounded, evidence-based, and aligned with the user's actual outcome. Use for broad or long-running tasks, plans that mix review and implementation, multi-agent work, continuation prompts, "go deep" or "end-to-end" requests, repeated corrections, possible rabbit holes, overengineering risk, status or completion audits, and requests to review prior sessions for drift or hallucination. Detect scope changes, define a compact task contract, pause before unauthorized or materially different work, distinguish verified facts from inference, and close at a clear stopping point. Do not use for trivial one-step questions unless the user invokes it explicitly.
---

# Stay on Track

Keep the task's outcome primary. Add only the minimum structure needed to prevent drift; do not turn the skill itself into a governance project.

## Choose the mode

- Use **preflight** before a complex task begins.
- Use **in-flight check** when the user adds work, says `proceed`, changes direction, or asks whether the work is still aligned.
- Use **closure check** before claiming completion.
- Use **retrospective** when reviewing a past session, prompt history, agent behavior, or suspected hallucination.

For a simple, low-risk task with one obvious deliverable, proceed without displaying a formal contract.

## Establish the task contract

For complex work, state a compact contract before material edits or external mutations:

```text
Outcome: one observable result
Deliverable: the artifact, decision, or behavior to produce
Authority: allowed changes and actions requiring approval
Proof: evidence that will establish completion
Stop: the exact boundary for this task
Deferred: adjacent work explicitly left for later
```

Infer missing details only when the smallest safe interpretation is clear. If ambiguity could change architecture, external state, cost, data exposure, or the deliverable, pause and ask one concise question or present a proposed contract for approval.

Keep stable preferences in `AGENTS.md`, not in the task contract. Keep project truth in current repository documentation. Keep only this task's slice in the prompt.

## Classify before acting

Classify the request as one primary mode:

- **Explain/report:** inspect and answer; do not edit.
- **Review/audit:** identify findings and evidence; do not fix unless asked.
- **Diagnose:** determine root cause; do not implement unless asked.
- **Plan/design:** produce a decision-ready plan; do not begin implementation.
- **Implement/fix:** make the bounded change and verify it.
- **Operate/mutate:** perform the explicitly authorized external action and verify remote state.
- **Monitor/wait:** observe the named condition without expanding scope.

If the request mixes modes, choose the earliest decision boundary. Separate discovery from implementation unless the user clearly authorized both and the implementation target is already unambiguous.

## Run the preflight

Check these questions:

1. What single outcome ends this task?
2. What is the authoritative current-state source?
3. Which repository, branch, environment, and artifact are in scope?
4. What may be changed without further approval?
5. What evidence will prove the result?
6. What adjacent work must remain deferred?

For prompt audits or unusually broad prompts, run `scripts/score_prompt.py` with `--text` or `--file`. Treat its output as a warning signal, not as authority.

## Prevent rabbit holes and overengineering

Apply these gates throughout execution:

### Critical-path gate

Before a new investigation or implementation branch, ask:

- Does this directly advance the contracted outcome?
- Is it necessary for the proof requirement?
- Is the blocker reproduced or only imagined?
- Can the task finish safely without it?

If the answer is no, record it under `Deferred` and continue with the critical path.

### Minimum-change gate

Do not introduce a new framework, service, protocol layer, abstraction, data store, agent role, or governance artifact unless all are true:

1. A concrete limitation in the existing path is reproduced.
2. The limitation blocks the contracted outcome.
3. A smaller change was considered and rejected with evidence.
4. The new mechanism has a verification path.

### Investigation budget

- Test at most three plausible hypotheses before reassessing the framing.
- After two failed approaches, return to the source of truth and compare against a known-good baseline.
- Do not broaden web research merely because more sources exist. Stop when the decision has enough reliable evidence.
- Do not create documentation that duplicates an existing canonical artifact.

## Detect and handle drift

Run an in-flight check when any of these occurs:

- The named milestone, repository, audience, or deliverable changes.
- A read-only task starts producing edits.
- A review starts fixing findings.
- A plan starts implementing itself.
- The user adds deployment, Git delivery, outreach, publication, or another external mutation.
- The task begins creating infrastructure whose purpose is only to manage the task.
- A new request would require a different success condition.
- The conversation has compacted repeatedly, accumulated many corrections, or can no longer state current truth succinctly.

Respond with:

```text
Boundary check
- Original outcome:
- Newly requested work:
- Why it is inside or outside the current contract:
- Safe action now:
- Deferred/new-task action:
```

If the new work is materially different, finish or hand off the current task and recommend a new task. Do not silently absorb it.

## Use subagents narrowly

- Delegate only independent, bounded questions that can run in parallel.
- Give each worker one deliverable, authoritative sources, allowed paths, and a stop condition.
- Prevent overlapping writers unless isolation is explicit.
- Keep synthesis, scope decisions, and completion judgment with the primary agent.
- Do not spawn agents merely to appear thorough.

## Maintain evidence discipline

Use the narrowest accurate status label:

- `OBSERVED`: directly read from current source, state, or output.
- `INFERRED`: reasoned from evidence but not directly confirmed.
- `PROPOSED`: designed or recommended, not implemented.
- `IMPLEMENTED`: changed locally, not necessarily tested.
- `TESTED`: named checks passed.
- `VERIFIED`: required behavior or remote state was independently confirmed.
- `DEPLOYED`: confirmed in the target environment.
- `BLOCKED`: cannot proceed without a named dependency or decision.

Do not call a claim a hallucination merely because the user corrected the agent. Read `references/failure-taxonomy.md` when diagnosing failures. Require authoritative contradictory evidence before labeling a factual hallucination.

Prefer current code, tests, runtime state, logs, and remote state over summaries. Treat historical conversations and memory as routing context, not current operational truth.

## Protect session health

Prepare a handoff and recommend a fresh task when one or more are true:

- The original milestone is complete and a new milestone is starting.
- The task crosses into a different repository or external system.
- Repeated compaction makes the original contract hard to recover.
- Corrections have materially changed the architecture or deliverable.
- The remaining work needs a different proof standard.
- A concise current-state summary cannot be produced without re-reading most of the transcript.

A handoff must contain current verified state, completed work, evidence, unresolved blockers, dirty-worktree or external-state warnings, and exactly one recommended next slice.

## Close without overclaiming

Before saying `done`, verify the contracted proof. Report:

1. Outcome verdict.
2. Evidence and checks actually run.
3. Material changes made.
4. Anything implemented but not verified.
5. Blockers or risks.
6. Deferred work.

Do not equate files written with behavior verified, tests passed with deployment proven, a supervised success with unattended reliability, or a research pack with learning integrated into the system.

## Run a retrospective

When reviewing sessions:

1. Separate user-originated tasks, subagents, automations, and internal reviews.
2. Sample both normal and failed/long traces; do not inspect only dramatic cases.
3. Apply open coding to concrete failures, then group them using `references/failure-taxonomy.md`.
4. Quantify prevalence and distinguish facts from heuristic signals.
5. Compare affected and unaffected sessions where possible.
6. Identify user-side, agent-side, workflow-side, and environment-side causes separately.
7. Convert repeated failures into one targeted change, then test it on representative cases.

Never publish a hallucination rate without ground-truth labeling. Report `possible unsupported-claim events` or `completion challenges` until the underlying claims have been checked.

