# Failure taxonomy

Use this reference for retrospective reviews and in-flight diagnoses. Choose the narrowest supported label.

| Label | Meaning | Minimum evidence |
|---|---|---|
| Scope drift | Work moved beyond the original outcome or stop boundary. | Compare the original contract with later actions. |
| Goal substitution | The agent optimized a proxy rather than the requested result. | Show the requested result and the substituted target. |
| Deliverable mismatch | The output type was wrong even if its content was useful. | Compare intended use with the artifact produced. |
| Architecture drift | Implementation violated or replaced a governing design principle. | Cite the accepted principle and conflicting implementation. |
| Overengineering | New machinery was added without a reproduced blocker or minimum-change analysis. | Identify the new mechanism and the smaller viable path. |
| Rabbit hole | Investigation continued after it no longer affected the decision or proof. | Show the decision point and subsequent non-critical work. |
| Stale-state claim | A claim relied on old state after code, runtime, branch, or remote state changed. | Compare timestamps or current readback. |
| Unsupported claim | A statement lacked adequate evidence. | Show the claim and missing evidence source. |
| Factual hallucination | A concrete factual claim contradicted authoritative evidence available to the workflow. | Cite both the claim and contradictory source. |
| False completion | The agent said or implied completion without satisfying the agreed proof. | Compare the completion claim with the contract. |
| Verification gap | Implementation occurred but the required check was absent or inconclusive. | Name the missing test, runtime check, or remote readback. |
| Authority breach | The agent performed or prepared a consequential action beyond authorization. | Compare action with explicit authority. |
| Premature escalation | The agent asked the user before exhausting safe in-scope discovery. | Show available evidence it failed to inspect. |
| Late clarification | A material ambiguity was discovered only after expensive work. | Show the ambiguity and work performed before resolving it. |
| Context overload | Excess context obscured the task contract or displaced relevant details. | Show repeated history, duplicated prompt sections, or compaction effects. |
| Handoff failure | A continuation lacked verified state, evidence, boundaries, or next action. | Compare handoff with the required fields. |

## Causal ownership

Assign one or more causes without blame:

- **User-side:** unclear result, mixed work modes, late scope addition, ambiguous referent, or conflicting instruction.
- **Agent-side:** failed to clarify, overclaimed, ignored a boundary, expanded scope, or chose unnecessary machinery.
- **Workflow-side:** missing canonical state, weak handoff, overlapping writers, no evaluation set, or absent approval gate.
- **Environment-side:** stale process, missing tool, permissions, network, wrong repository, or provider inconsistency.

## Severity

- `S0 observation`: stylistic friction with no outcome effect.
- `S1 inefficiency`: avoidable time, tokens, or repeated work.
- `S2 quality risk`: likely wrong deliverable, weak evidence, or missed requirement.
- `S3 consequential risk`: unauthorized mutation, false deployment/readiness claim, data loss, security, financial, or production risk.

## Retrospective output

For each finding, report:

```text
Pattern:
Count and denominator:
Severity:
Evidence:
Likely cause:
User-side improvement:
Agent/workflow improvement:
Confidence and limitations:
```

