---
name: orchestrate
description: Coordinate substantial Codex work through a primary coordinator and specialized Scout, Worker, and Smart Worker agents, routing every delegated work package through skill-router so each agent receives the right installed skills. Use when a task has two or more independent investigation or implementation domains that benefit from parallel ownership; do not use for trivial, tightly coupled, or conflicting write-heavy work.
---

# Orchestrate

Keep the primary agent available to the user. The primary agent owns decomposition, approvals, integration, and final verification.

## Map work to roles

- Use `scout` (`gpt-5.6-luna`, High) for narrow, read-only discovery: locate files, trace execution paths, find tests, or verify documentation. Start with fresh context unless prior decisions are essential.
- Use `worker` (`gpt-5.6-terra`, Medium) for routine, bounded implementation and its directly relevant checks.
- Use `smart_worker` (`gpt-5.6-sol`, High) for difficult implementation, ambiguous root causes, or cross-component reasoning.
- Keep coordination with the primary agent. Treat all spawned roles as leaves unless the assignment explicitly grants delegation authority.

The installed custom-agent files define the model, reasoning effort, sandbox, and permanent role instructions. Select the named role instead of recreating its identity ad hoc.

## Route skills to agents

Treat role and skill selection as separate decisions:

- The role selects the model, reasoning effort, and permissions.
- `$skill-router` selects the domain workflow, tools, and procedural instructions.

Read `C:\Users\neela\.codex\skills\skill-router\SKILL.md` completely before the first routing decision in an orchestration run. The primary coordinator owns initial routing; leaves may request rerouting but must not silently replace assigned skills.

Before spawning an agent, route its focused work-package description rather than the entire broad user request:

```powershell
py "C:\Users\neela\.codex\skills\skill-router\scripts\route_skills.py" --query "<focused work package>" --cwd "<current working directory>" --limit 8
```

If the user explicitly named a skill for that package, use it directly. Otherwise inspect the shortlist and select the smallest sufficient set, normally one skill and at most three. Treat ranking as retrieval evidence, not an automatic choice: reject skills whose platform, provider, artifact, or workflow assumptions are not established by the request or repository, then refine the routing query once. Do not assign `$orchestrate` to a leaf agent unless that agent was explicitly granted delegation authority.

Include each routed skill's exact name and absolute `SKILL.md` path in the assignment. Require the agent to read every assigned `SKILL.md` completely before acting and follow the skills in dependency order. If a selected skill is missing, unreadable, contradictory, or clearly mismatched after inspection, the agent must report that to the coordinator and request rerouting instead of silently substituting a workflow.

Use this assignment contract:

- Role and owner scope
- Concrete outcome
- Routed skills: exact names and absolute paths
- Instruction to read and apply those skills before work
- Constraints, file boundaries, and no-spawn rule
- Expected evidence or checks

## Coordinate the team

1. Separate the request into genuinely independent domains. Do not delegate merely to increase agent count.
2. Route each work package through `$skill-router`, then choose the role appropriate to its complexity and permissions.
3. Give every agent one distinct owner scope using the assignment contract above.
4. Avoid overlapping edits. Prefer parallel Scouts; parallel Workers are appropriate only when their file and subsystem ownership cannot conflict.
5. Use fresh context for narrow Scouts. Inherit conversation context only when the agent needs earlier requirements or decisions, and repeat any essential safety or tool boundaries in the assignment.
6. Tell leaf agents not to spawn other agents. Ask them to send dependency findings directly to the teammate who needs them when direct messaging is available.
7. Stay responsive to the user while agents run. Keep approvals and material scope decisions in the primary thread.
8. Wait for all required results, reconcile contradictions, inspect shared-workspace changes, and run integration checks at the primary level. Confirm that each agent used or explicitly rejected its routed skills before accepting its result.

The concurrency budget is three spawned agents plus the primary coordinator. Use fewer whenever fewer independent domains exist. Unnamed subagents default to `gpt-5.6-luna` at Extra High (`xhigh`) reasoning.
