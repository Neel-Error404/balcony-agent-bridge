---
name: symphony-setup
description: Use when setting up Symphony for a repo, generating a repo-local WORKFLOW.md from founder logs and repo structure, and deciding the correct execution topology.
---

# Symphony Setup

## Purpose

This skill sets up Symphony in the right shape for a real project repo.

Use it to:
- decide whether Symphony should run per repo or per project family
- read founder logs and repo structure before drafting `WORKFLOW.md`
- generate or refresh a repo-local Symphony workflow contract
- keep the central governance repo as standards/memory, not the mandatory execution path

## Core Model

Default model:

- central standards repo: templates, doctrine, setup guidance, shared learnings
- project repo: founder logs, repo-local `WORKFLOW.md`, tests, scripts, actual code
- tracker: Linear or Jira as the control surface
- Symphony: long-running repo-local orchestrator
- Codex: worker that reads the ticket plus `WORKFLOW.md`

Do not start with one giant multi-repo Symphony runtime unless there is already a proven reason to centralize execution.

## When To Use

- onboarding Symphony into a real repo
- refreshing `WORKFLOW.md` after architecture or process changes
- converting founder-log knowledge into executable repo instructions
- deciding whether a repo should have one workflow or multiple workflow modes

## Required Inputs

Before drafting setup:
1. repo root
2. founder-log roots or equivalent memory docs
3. test/validation surfaces
4. tracker choice: Linear or Jira
5. whether the repo is:
   - ticket-to-PR execution heavy
   - exploratory/research heavy
   - write-enabled with strict approvals

## Read Order

Read only what is needed:
1. repo founder logs / current-state docs
2. repo architecture docs
3. test or QA scripts
4. existing repo automation docs
5. then draft `WORKFLOW.md`

Do not draft `WORKFLOW.md` from generic assumptions if repo-local founder logs already explain how the system works.

## What To Build

For a normal software repo using Symphony, create or refresh:

1. `WORKFLOW.md`
2. a short setup note documenting:
   - tracker mapping
   - branch / PR expectations
   - validation surfaces
   - any mandatory founder-log documents
3. optional `.symphony/` adapter files if this repo also participates in the local governance wrapper

## WORKFLOW.md Guidance

Prefer one strong workflow contract per repo before inventing multiple workflows.

Inside one `WORKFLOW.md`, specify:
- how to understand a ticket
- what founder logs/docs to read first
- how to plan
- how to implement
- how to test
- how to validate
- how to open or update a PR
- how to respond to review feedback

Create multiple workflow modes only when the repo truly has distinct classes of work, for example:
- feature work
- bugfix / incident review
- documentation only
- release / migration

Even then, keep them as clearly separated sections or modes in the repo-local workflow contract rather than scattering logic across many unrelated prompts.

## Setup Sequence

1. identify the repo and confirm Symphony should be repo-local
2. inspect founder logs and core docs
3. identify build, test, and QA commands
4. identify browser / desktop / API validation surfaces
5. draft or refresh `WORKFLOW.md`
6. document tracker mapping and control-surface assumptions
7. if governance is still desired, run repo bootstrap as a separate step
8. validate that the repo now has enough instruction for a worker to act without conversational babysitting

## Safety Rules

- Do not turn the central governance repo into the mandatory execution plane for basic ticket work.
- Do not create a vague `WORKFLOW.md`; it should be specific enough that the worker can plan, test, and stop correctly.
- Do not assume multi-agent workflows are needed. Start with one worker per ticket.
- Do not force governance-specific approval ceremony into a repo that only needs normal ticket-to-PR flow.

## Deliverable

When using this skill, produce:

```text
Symphony Setup Decision
- repo:
- execution_topology:
- tracker_surface:
- founder_log_sources:
- workflow_strategy:
- validation_surfaces:
- governance_role:
```

Then produce:

```text
Setup Plan
- files to create or refresh:
- setup order:
- risks:
- validation step:
```
