---
name: eli5
description: Create a dead-simple visual explanation of a topic as a self-contained HTML artifact with big pictures and few words. Use when the user invokes $eli5, writes /eli5, asks to explain something like they are five or know nothing about it, or requests a simple picture explainer for a concept, code module, architecture decision, tradeoff, or incident.
---

# ELI5 Visual Explainer

Turn the requested topic into a visual story for a complete beginner. Produce an HTML artifact, not a long prose answer.

## Workflow

1. Identify the topic from the user's full request. Proceed without questions unless a genuine ambiguity would materially change the explanation.
2. Establish the facts before simplifying:
   - For a general topic, use reliable domain knowledge and verify unstable claims when needed.
   - For a repository topic, inspect the relevant source, documentation, configuration, tests, history, or logs. Explain what the system actually does; do not invent a generic version.
   - For a tradeoff or incident, distinguish observed evidence from inference.
3. Choose one concrete mental model or analogy. Map each important part of the real topic to one familiar object or action.
4. Outline three to six visual beats. Give each beat one idea, one large visual, and at most two short sentences.
5. Build a single self-contained `.html` file with embedded CSS and JavaScript. Prefer inline SVG, CSS shapes, diagrams, arrows, and small animations over external images. Do not require a build step or network-loaded dependencies.
6. Save the artifact in the task's user-facing output directory when one is defined; otherwise save it in an appropriate workspace output directory. Use a descriptive filename such as `eli5-dns.html`.
7. Preview the artifact when the environment supports it, then provide a direct link to the saved file.

## Visual and writing rules

- Assume zero prior knowledge.
- Lead with the simplest useful answer, then reveal how the pieces connect.
- Use big pictures, large type, generous spacing, and very few words.
- Use plain language. Define every unavoidable technical term in place.
- Make the visual carry the explanation; do not turn the artifact into a decorated essay.
- Use a coherent visual metaphor, but label where the analogy stops matching reality.
- Use semantic HTML, readable contrast, visible focus states, reduced-motion support, and responsive layouts.
- Add useful alt text or accessible labels for meaningful visuals.
- End with one short `What to remember` statement.
- Keep optional technical detail behind a small disclosure only when it materially helps.

## Quality gate

Before handing off the artifact, verify that:

- A newcomer can state the main idea after a quick scan.
- Each panel teaches exactly one idea.
- The pictures are understandable without reading a paragraph.
- Repository-specific claims match the inspected evidence.
- The file opens locally without external dependencies or console errors.
- The artifact works at narrow and wide viewport sizes.
