from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


def present(pattern: str, text: str) -> bool:
    return bool(re.search(pattern, text, re.IGNORECASE | re.MULTILINE))


def score(text: str) -> dict:
    normalized = re.sub(r"\s+", " ", text).strip()
    action_text = re.sub(
        r"\b(?:do not|don't|never)\s+(?:\w+\s+){0,2}"
        r"(?:implement|fix|build|create|update|change|edit|deploy|send|publish|submit|commit|push|merge|delete)\b",
        "",
        normalized,
        flags=re.IGNORECASE,
    )
    modes = {
        "review": present(r"\b(review|audit|assess|understand|analy[sz]e)\b", normalized),
        "implement": present(r"\b(implement|fix|build|create|edit)\b", action_text)
        or present(
            r"(?:^|[.!?]\s+)(?:please\s+)?(?:update|change)\s+"
            r"(?:the|this|that|my|our|a|an|file|code|config|setting|implementation)\b",
            action_text,
        ),
        "operate": present(r"\b(deploy|send|publish|submit|commit|push|merge|delete)\b", action_text),
        "research": present(r"\b(research|search|internet|web|firecrawl)\b", normalized),
    }
    methods = {
        "agents": present(r"\b(subagents?|multi[- ]?agents?|orchestrat)\b", normalized),
        "skills": present(r"\bskills?\b", normalized),
        "memory": present(r"\b(memory|obsidian|founder[_ ]logs?|knowledge graph)\b", normalized),
        "web": present(r"\b(internet|web|firecrawl|research)\b", normalized),
        "testing": present(r"\b(test|verify|verification|evidence|prove)\b", normalized),
        "git": present(r"\b(git|commit|push|branch|merge|pull request)\b", normalized),
    }
    checks = {
        "outcome": present(r"\b(goal|outcome|objective|deliverable|deliver|result|verdict|findings?|report|fix|implement|create)\b", normalized),
        "context": present(r"[A-Za-z]:[\\/]|\b(context|current state|repo|repository|file|error|log)\b", normalized),
        "constraints": present(r"\b(constraint|must|do not|don't|never|only|preserve|avoid)\b", normalized),
        "verification": present(r"\b(test|verify|verification|evidence|prove|done when|success condition|pass(?:es|ed)?)\b", normalized),
        "stop": present(r"\b(stop|do not begin|do not continue|only this|end after|finish after)\b", normalized),
    }
    checks["outcome"] = checks["outcome"] or modes["implement"] or modes["operate"]
    signals = {
        "oversized": len(normalized) >= 2500,
        "open_ended_scope": present(r"\b(everything|entire|all aspects|what all|end[- ]to[- ]end|go deep|complete picture)\b", normalized),
        "mixed_modes": sum(modes.values()) >= 2,
        "method_overload": sum(methods.values()) >= 4,
        "external_mutation": modes["operate"],
        "thin_continuation": len(normalized) < 350 and present(r"codex://threads/|\bcontinue\b|\bresume\b|from where (?:we|it) left", normalized),
    }

    risk = 0
    risk += 3 if signals["oversized"] else 0
    risk += 3 if signals["open_ended_scope"] else 0
    risk += 3 if signals["mixed_modes"] else 0
    risk += 2 if signals["method_overload"] else 0
    risk += 2 if signals["external_mutation"] and not checks["constraints"] else 0
    risk += 3 if signals["thin_continuation"] else 0
    needs_boundaries = len(normalized) >= 500 or signals["open_ended_scope"]
    risk += 1 if needs_boundaries and not checks["verification"] else 0
    risk += 1 if needs_boundaries and not checks["stop"] else 0

    if risk >= 7:
        level = "high"
    elif risk >= 3:
        level = "moderate"
    else:
        level = "low"

    recommendations = []
    if not checks["outcome"]:
        recommendations.append("Name one observable outcome.")
    if signals["mixed_modes"]:
        recommendations.append("Choose the earliest work mode or split review from implementation.")
    if signals["open_ended_scope"]:
        recommendations.append("Replace open-ended scope with a bounded artifact or decision.")
    if needs_boundaries and not checks["verification"]:
        recommendations.append("Add evidence that will prove completion.")
    if needs_boundaries and not checks["stop"]:
        recommendations.append("Add a stop boundary and explicitly defer adjacent work.")
    if signals["method_overload"]:
        recommendations.append("Keep only methods necessary for the outcome; let the agent choose the rest.")
    if signals["thin_continuation"]:
        recommendations.append("Add verified current state, remaining work, and the next bounded slice.")

    return {
        "characters": len(normalized),
        "risk_score": risk,
        "risk_level": level,
        "contract_fields_detected": checks,
        "work_modes_detected": [name for name, value in modes.items() if value],
        "risk_signals": [name for name, value in signals.items() if value],
        "recommendations": recommendations,
        "note": "Heuristic preflight only; inspect the actual task and evidence before deciding.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Score a Codex prompt for drift and scope risk.")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--text", help="Prompt text to score.")
    group.add_argument("--file", type=Path, help="UTF-8 text file containing the prompt.")
    args = parser.parse_args()
    text = args.text if args.text is not None else args.file.read_text(encoding="utf-8")
    print(json.dumps(score(text), indent=2))


if __name__ == "__main__":
    main()
