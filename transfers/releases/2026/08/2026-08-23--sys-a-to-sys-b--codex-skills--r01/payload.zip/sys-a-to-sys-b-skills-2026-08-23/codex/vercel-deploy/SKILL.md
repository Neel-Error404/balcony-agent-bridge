---
name: vercel-deploy
description: Deploy applications and websites to Vercel. Use when the user requests deployment actions like "deploy my app", "deploy and give me the link", "push this live", or "create a preview deployment".
---

# Vercel Deploy

Deploy any project to Vercel instantly. **Always deploy as preview** (not production) unless the user explicitly asks for production.

## Multi-Service Guardrail

If the project is part of a larger release path with a separate backend, auth service, origin-based CORS, or shared secret/config dependencies, this skill alone is not sufficient to declare the system ready.

In those cases:
- use the repo-specific release-readiness skill first if one exists,
- classify the change as `frontend-only`, `backend-only`, or coordinated `both`,
- prefer a stable preview hostname or branch alias when the backend allowlists exact origins,
- do not equate a successful Vercel deploy with an end-to-end release.

For the VoiceAI / SurveyAI repo specifically, use `voiceai-release-readiness` before treating a frontend deploy as releasable.

## Branch Governance

Before treating a Vercel production deploy as "Git-driven" rather than a one-off manual release, verify that branch ownership is coherent across GitHub and Vercel.

Recommended branch model:
- `main` = sacred production truth
- `develop` = integration branch
- feature branches feed `develop`, then `develop` feeds `main`

For the VoiceAI / SurveyAI repo specifically:
- `main` is the production truth branch
- `develop` is the merge and validation branch
- `master` must not remain an active second source of truth once branch migration is complete

Minimum branch checks before a production claim:
- GitHub default branch is the intended production branch
- Vercel project `link.productionBranch` matches that branch
- a successful manual CLI promotion is not treated as proof that future Git pushes will auto-deploy production

## Prerequisites

- Check whether the Vercel CLI is installed **without** escalated permissions (for example, `command -v vercel`).
- Only escalate the actual deploy command if sandboxing blocks the deployment network calls (`sandbox_permissions=require_escalated`).
- The deployment might take a few minutes. Use appropriate timeout values.
- Use the Vercel CLI and `vercel api` as the source of truth for this workflow.

## Quick Start

1. Check whether the Vercel CLI is installed (no escalation for this check):

```bash
command -v vercel
```

2. If `vercel` is installed, run this (with a 10 minute timeout):
```bash
vercel deploy [path] -y
```

**Important:** Use a 10 minute (600000ms) timeout for the deploy command since builds can take a while.

3. If `vercel` is not installed, or if the CLI fails with "No existing credentials found", use the fallback method below.

## Fallback (No Auth)

If CLI fails with auth error, use the deploy script:

```bash
skill_dir="<path-to-skill>"

# Deploy current directory
bash "$skill_dir/scripts/deploy.sh"

# Deploy specific project
bash "$skill_dir/scripts/deploy.sh" /path/to/project

# Deploy existing tarball
bash "$skill_dir/scripts/deploy.sh" /path/to/project.tgz
```

The script handles framework detection, packaging, and deployment. It waits for the build to complete and returns JSON with `previewUrl` and `claimUrl`.

**Tell the user:** "Your deployment is ready at [previewUrl]. Claim it at [claimUrl] to manage your deployment."

## Production Deploys

Only if user explicitly asks:
```bash
vercel deploy [path] --prod -y
```

If production is supposed to be driven by Git merges rather than manual promotions, verify branch wiring after the deploy:

```bash
gh repo view <owner>/<repo> --json defaultBranchRef
vercel api /v9/projects/<projectId> --scope <scope> --raw
```

Treat production branch automation as healthy only when `link.productionBranch` matches the intended GitHub default branch.

## Output

Show the user the deployment URL. For fallback deployments, also show the claim URL.

If a repo-specific release skill exists, follow its validation contract after deployment instead of stopping at the link.

## Troubleshooting

### Git Link Drift Or Stale Production Branch

If Vercel is connected to the correct repo but production is still effectively following an old branch, repair the Git connection through the CLI and then re-check `link.productionBranch`.

Preferred recovery path:

```bash
vercel git connect https://github.com/<owner>/<repo>.git --scope <scope>
vercel api /v9/projects/<projectId> --scope <scope> --raw
```

Notes:
- In worktree-based repos, Vercel may fail to infer Git metadata from the current checkout because `.git/config` is not present in the worktree path.
- If CLI debug output shows it cannot read `.git/config`, pass the repo URL explicitly as above.
- If the checkout itself is not the Git repo root, running the command from the repo root is safer.
- The recovery is complete only when the project JSON exposes `link.productionBranch` with the intended branch, for example `main`.

### Escalated Network Access

If deployment fails due to network issues (timeouts, DNS errors, connection resets), rerun the actual deploy command with escalated permissions (use `sandbox_permissions=require_escalated`). Do not escalate the `command -v vercel` installation check. The deploy requires escalated network access when sandbox networking blocks outbound requests.

Example guidance to the user:

```
The deploy needs escalated network access to deploy to Vercel. I can rerun the command with escalated permissions—want me to proceed?
```
