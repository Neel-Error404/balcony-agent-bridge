---
name: architecture-review-html
description: Use when auditing a codebase for architecture friction, shallow modules, poor seams, testability gaps, or refactor opportunities before changing code
---

# Architecture Review HTML

## Goal

Produce a visual architecture report before refactoring. The report ranks deepening opportunities and lets the user choose what to explore.

Use `domain-modeling` for project vocabulary and `test-driven-development` for seam thinking.

## Vocabulary

- Module: anything with an interface and implementation.
- Interface: everything callers must know to use the module.
- Seam: where behavior can vary without editing callers.
- Adapter: a concrete implementation behind a seam.
- Depth: leverage behind a small interface.
- Locality: bugs and changes concentrate in one place.

Avoid vague labels like "cleaner" or "better." Name the seam, interface, and locality win.

## Explore

Look for:

- Shallow modules whose interface is nearly as complex as implementation.
- Logic scattered across many call sites.
- Tests coupled to internals.
- Repeated conditionals over the same domain concept.
- Adapters that are fake seams with only one implementation.
- Missing seams that block regression tests.
- ADRs that explain why a tempting refactor was rejected.

## Report

Write a self-contained HTML report to the OS temp directory, not the repo, unless the user asks to save it.

Each candidate should include:

- Title.
- Files/modules involved.
- Problem.
- Proposed deepening.
- Before/after diagram or schematic.
- Testing impact.
- Recommendation: Strong, Worth exploring, or Speculative.

End with one top recommendation and why.

## After The Report

Do not implement immediately. Ask which candidate to explore. For the chosen candidate, use `domain-modeling`, `prototype`, or `to-issues` as appropriate.
