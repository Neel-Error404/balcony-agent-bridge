# Method Selection And Evidence Weight

## Contents

1. Research modes
2. Source-role hierarchy
3. Appraisal prompts
4. Confidence calibration
5. Large-corpus design

## Research Modes

| Mode | Best framing | Search emphasis | Appraisal emphasis | Typical stop |
| --- | --- | --- | --- | --- |
| Factual lookup | Exact claim, entity, date, or value | Current primary source first | Identity, version, date, directness | Primary source found and checked |
| Exploratory landscape | Concepts, actors, mechanisms, boundaries | Broad query families, citation expansion, grey literature | Coverage and category diversity | Concept saturation with category coverage |
| Literature review | Explicit question and eligibility criteria | Multiple databases, controlled terms, citation tracing | Study design, bias, applicability | Protocol complete and included set stabilized |
| Decision support | Alternatives, criteria, constraints, consequences | Evidence for each option and downside | Relevance, independence, base rates, tradeoffs | Decision criteria populated with bounded uncertainty |
| Due diligence | Claims, risks, ownership, incentives, history | Primary records, filings, official data, contrary searches | Provenance, conflicts, omissions, current status | Material claims checked and red flags classified |
| OSINT verification | Who, what, when, where, provenance | Reverse search, archives, metadata, maps, independent witnesses | Provenance, manipulation, timeline, location | Claim verified, falsified, or explicitly unresolved |
| Empirical design | Feasible and ethical research question | Prior methods, measures, datasets, power, protocols | Construct validity, sampling, analysis, reproducibility | Protocol can be executed and audited |

## Source-Role Hierarchy

Do not assign permanent universal tiers. Assign a role relative to the claim.

1. **Primary evidence:** original record, dataset, filing, standard, official
   documentation, direct observation, or original study.
2. **Methodologically strong synthesis:** systematic review, meta-analysis,
   evidence guideline, or transparent multi-source report.
3. **Independent expert interpretation:** domain expert, institutional guide,
   or high-quality analysis that explains primary evidence.
4. **Context and discovery:** journalism, vendor material, advocacy, blogs,
   forums, and social posts.

A fourth-role source may expose a lead but should not carry a central factual
claim when stronger evidence exists.

Assess independence at the evidence level. Multiple articles repeating one
press release are one evidentiary line.

## Appraisal Prompts

### All Sources

- What exact claim can this source support?
- How close is it to the underlying data or event?
- What method produced the claim?
- What is missing or unreported?
- What incentives or conflicts could shape presentation?
- Is it current enough for this claim?
- Can another source independently reproduce or corroborate it?

### Quantitative Evidence

- Was the design suitable for causal, predictive, or descriptive claims?
- Was the sample defined before analysis and large enough for the question?
- Are outcome definitions, denominators, missing data, and exclusions clear?
- Are effect sizes and uncertainty reported, not only significance?
- Were multiple analyses, model choices, and robustness checks handled openly?
- Does the conclusion generalize beyond the observed population?

### Qualitative Evidence

- Is the methodology congruent with the research question and philosophy?
- Is the sampling logic explained and appropriate?
- Does the researcher account for their interpretive role?
- Is the path from data to codes, themes, or theory visible?
- Are negative cases, ambiguity, and context preserved?
- Is saturation defined and demonstrated rather than asserted?

### Reviews And Syntheses

- Was a protocol or pre-specified method used?
- Are eligibility criteria explicit and consistently applied?
- Did searches cover appropriate databases, grey literature, and citation
  trails?
- Were screening and extraction checked independently where risk justifies it?
- Were study quality and risk of bias assessed?
- Does the synthesis method match the data and heterogeneity?
- Are missing studies, publication bias, and conflicts considered?

### Online Claims And Media

- Is this the original content or a copy?
- Who produced it, and is that identity independently supported?
- When and where was it created?
- Has context, cropping, editing, or translation changed meaning?
- What motivation or incentive may explain publication?
- What would falsify the working hypothesis?

## Confidence Calibration

Use three levels unless the domain requires a formal scheme.

**High**

- direct evidence from appropriate methods
- independently corroborated
- current and applicable
- no unresolved material contradiction

**Moderate**

- useful evidence with one material limitation
- indirectness, limited independence, method uncertainty, or mixed findings
- conclusion likely but boundary conditions matter

**Low**

- sparse, derivative, conflicting, outdated, or weakly applicable evidence
- inference depends heavily on assumptions
- report as tentative or unresolved

State why confidence has that level. Do not turn confidence into unexplained
numbers.

## Large-Corpus Design

For 50-60 sources, plan quotas before searching. Adapt the mix to the task.

Example 55-source allocation:

| Evidence slice | Target |
| --- | ---: |
| Primary records, official standards, or original studies | 15 |
| Strong reviews or methodological syntheses | 10 |
| Independent institutional or expert guidance | 10 |
| Current implementation, cases, or field evidence | 8 |
| Contrarian, limitation, failure, or risk evidence | 7 |
| Context and discovery sources | 5 |

Do not fill quotas with weak sources. Reallocate only with a recorded reason.

In the final search round, inspect:

- proportion of duplicates
- number of genuinely new concepts
- unresolved evidence categories
- source independence
- whether new sources would change a decision or confidence level
