---
name: writing-great-skills
description: Use when creating, pruning, rewriting, reviewing, or reorganizing agent skills so they are predictable, discoverable, compact, and resistant to misuse
---

# Writing Great Skills

## Core Principle

A skill exists to make agent behavior predictable. It should change what the agent does, not merely describe what a good agent would do anyway.

## Invocation Design

Choose the smallest useful surface.

- Model-invoked: use when the agent must discover the skill automatically. Keep the description trigger-focused.
- User-invoked: use when the human will explicitly request it. This reduces context load.
- Router: use when many user-invoked skills exist and the human should not need to remember them all.

Descriptions should answer only "when should this be loaded?" Do not summarize the workflow in the description; agents may follow the summary and skip the body.

## Information Hierarchy

Put the most operational material highest.

1. In-skill steps: the actions the agent must take now.
2. In-skill reference: definitions and rules used during the run.
3. External reference: long examples, templates, APIs, or optional branches.

Use external files only when the branch is optional or the reference is heavy. Do not hide required behavior behind a link.

## Completion Criteria

Every step should end with a checkable done condition. Weak criteria cause premature completion.

Prefer:

- "Done when one command has reproduced the bug and its output is captured."
- "Done when each issue has acceptance criteria and blockers."

Avoid:

- "Be thorough."
- "Make a good plan."
- "Review carefully."

## Skill Shape

Use this default structure:

- Frontmatter: `name` and `description` only.
- Overview: one core principle.
- When to use and when not to use.
- Ordered process with completion criteria.
- Quick reference or checklist.
- Common mistakes and rationalizations.

Keep examples few and excellent. One strong example beats five mediocre ones.

## Pruning Rules

Delete no-ops:

- Generic advice the base agent already follows.
- Duplicated rules that appear elsewhere.
- Negation-heavy prose that makes the wrong behavior more salient.
- Narratives about one historical session.
- Process that cannot be checked.

Collapse repeated meanings into a stable leading word such as seam, tracer bullet, tight loop, brief, map, or fragment.

## Testing A Skill

Treat skill writing like TDD for process.

1. RED: identify the pressure scenario the old behavior fails.
2. GREEN: write the smallest skill text that changes that behavior.
3. REFACTOR: close loopholes and remove sediment.

If live subagent testing is not available, at minimum validate the skill by reading it against concrete pressure scenarios and recording the risk that behavioral testing is still pending.

## Common Mistakes

| Mistake | Fix |
|---|---|
| Description explains the workflow | Make it trigger-only. |
| Skill says "be careful" | Replace with a checkable action. |
| Skill grows into a handbook | Move optional reference behind files or split branches. |
| Skill forbids without target behavior | State the positive behavior first. |
| Skill includes commit/push by default | Preserve user git protocol and require explicit permission. |
