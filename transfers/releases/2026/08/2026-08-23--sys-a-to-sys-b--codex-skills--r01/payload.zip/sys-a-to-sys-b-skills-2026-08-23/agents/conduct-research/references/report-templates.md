# Research Output Templates

## Contents

1. Deep research report
2. Decision memo
3. Literature review
4. Verification brief
5. Rerun block

## Deep Research Report

```markdown
# [Question Or Topic]

## Answer
[Direct answer and confidence]

## Scope And Method
[Question, dates, search paths, source count, inclusion and exclusion rules]

## Key Findings
1. [Finding, evidence, confidence]
2. [...]

## Detailed Synthesis
[Organize by claim, mechanism, or theme]

## Disagreement And Alternative Explanations
[Where evidence conflicts and why]

## Limitations And Open Questions
[What remains uncertain or unavailable]

## Sources And Exclusions
[Included sources by role, plus material exclusions]

## Rerun Inputs
[Queries, databases, filters, dates, and stop rule]
```

## Decision Memo

```markdown
# Decision: [Choice]

## Recommendation
[One recommendation, confidence, and decisive reason]

## Criteria
| Criterion | Weight or importance | Evidence | Result |
| --- | --- | --- | --- |

## Options
[Evidence-weighted strengths, weaknesses, costs, risks, reversibility]

## What Would Change The Decision
[Thresholds, missing facts, and monitoring triggers]

## Method And Sources
[Research boundary and source roles]
```

## Literature Review

```markdown
# Literature Review: [Question]

## Abstract
[Question, method, included evidence, central result]

## Review Method
[Protocol, eligibility, search, screening, appraisal, synthesis]

## Evidence Landscape
[Study types, populations, dates, methods, gaps]

## Themes And Findings
[Synthesis by theme rather than source]

## Quality, Bias, And Applicability
[Evidence limitations and confidence]

## Disagreement And Research Gaps
[Contradictions and missing work]

## References
[Complete included set]
```

## Verification Brief

```markdown
# Verification: [Claim]

## Verdict
[Verified / false / misleading / unproven / outdated]

## Exact Claim
[Original wording and context]

## Evidence
[Primary record, provenance, date, location, corroboration]

## Verification Steps
[Queries, archives, tools, reverse searches, calculations]

## Contradictory Evidence
[What challenged the working hypothesis]

## Confidence And Residual Risk
[What remains unknown]
```

## Rerun Block

```yaml
research_question: ""
mode: ""
performed_at: ""
date_range: ""
geography: ""
languages: []
tools: []
queries: []
source_target: null
sources_read: 0
sources_excluded: 0
stop_rule: ""
status: complete
```
