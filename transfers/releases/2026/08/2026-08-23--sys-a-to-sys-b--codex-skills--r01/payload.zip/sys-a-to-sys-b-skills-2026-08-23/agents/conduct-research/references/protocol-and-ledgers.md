# Research Protocol And Ledgers

## Contents

1. Research brief
2. Search plan and log
3. Source ledger
4. Claim-evidence matrix
5. Exclusion vocabulary
6. Stop memo

## Research Brief

```markdown
# Research Brief: [working title]

## Decision
[What decision, explanation, or artifact must this research support?]

## Primary Question
[One answerable question]

## Subquestions
1. [...]
2. [...]

## Audience And Deliverable
[Audience, format, length, deadline]

## Scope
- Population or subject:
- Geography:
- Time period:
- Definitions:
- Included evidence:
- Excluded evidence:

## Source Requirements
- Required primary sources:
- Required independent sources:
- Required contrary viewpoints:
- Freshness:
- Target source count:

## Constraints And Authority
[Access, privacy, legal, safety, budget, or tool constraints]

## Stop Rule
[Coverage, saturation, count, time, and unresolved-blocker conditions]
```

## Search Plan And Log

Plan concept blocks before running queries.

| Concept | Synonyms and variants | Controlled terms | Exclusions |
| --- | --- | --- | --- |
| [A] | [...] | [...] | [...] |

Log every material search:

| Search ID | Timestamp | Tool or database | Exact query | Filters | Results reviewed | Sources retained | Notes |
| --- | --- | --- | --- | --- | ---: | ---: | --- |

Record changes to the query plan. A reproducible search includes unsuccessful
queries and boundary decisions, not just successful results.

## Source Ledger

Minimum fields:

| Field | Meaning |
| --- | --- |
| `source_id` | Stable local identifier |
| `canonical_url` | Deduplicated source URL or DOI |
| `title` | Source title |
| `author_org` | Author, publisher, or responsible institution |
| `published_at` | Publication or last-update date |
| `source_type` | Primary record, study, review, standard, dataset, report, expert analysis, media |
| `discovered_by` | Search ID, citation trail, or referral |
| `status` | Candidate, read, excluded, inaccessible, duplicate, superseded |
| `inclusion_role` | Claim or research subquestion served |
| `quality_notes` | Strengths, limitations, conflicts, and independence |
| `retrieved_at` | Retrieval timestamp |
| `artifact_path` | Local scrape, PDF, notes, or snapshot when retained |

Do not count `candidate`, `duplicate`, or `inaccessible` sources as read.

## Claim-Evidence Matrix

Use one row per atomic claim and source relationship.

| Claim ID | Claim | Source ID | Relationship | Evidence type | Context | Key result | Limitations | Confidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C-01 | [...] | S-01 | supports / contradicts / qualifies | [...] | [...] | [...] | [...] | high / moderate / low |

Add an `exact_location` field when page, section, table, timestamp, or line
verification will be needed later.

## Exclusion Vocabulary

Prefer typed reasons:

- `off_scope`
- `duplicate_work`
- `superseded_version`
- `insufficient_substance`
- `method_not_relevant`
- `unverifiable_authorship`
- `inaccessible_content`
- `outdated_for_current_claim`
- `derivative_without_added_evidence`
- `conflict_not_disclosed`
- `search_result_only`

Keep useful excluded sources in the ledger. Exclusion is part of the audit
trail.

## Stop Memo

```markdown
## Stop Decision

- Brief answered: yes / partial / no
- Required source classes covered:
- Sources read:
- Exclusions:
- Last searches attempted:
- New concepts in final search round:
- Duplicate rate in final search round:
- Central claims independently corroborated:
- Unresolved contradictions:
- Remaining evidence gaps:
- Stop classification: complete / partial / blocked
- Reason:
```
