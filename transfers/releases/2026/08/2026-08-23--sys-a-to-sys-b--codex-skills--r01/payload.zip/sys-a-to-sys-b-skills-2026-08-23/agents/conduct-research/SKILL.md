---
name: conduct-research
description: Conduct rigorous, auditable research from question framing through search, source evaluation, evidence extraction, synthesis, verification, and reporting. Use for deep web research, literature reviews, evidence syntheses, technical or market investigations, due diligence, OSINT-style verification, research planning, and any request that needs multiple sources, explicit uncertainty, or a defensible evidence trail rather than a quick lookup.
---

# Conduct Research

## Core Principle

Build a traceable chain from question to search to evidence to claim. Treat
research as a controlled reduction of uncertainty, not as collecting links or
summarizing pages.

## Workflow

### 1. Freeze The Research Brief

Classify the task before searching:

- factual lookup
- exploratory landscape or scoping review
- evidence review or literature review
- decision support or due diligence
- investigative verification or OSINT
- empirical study design

Write a brief containing:

- the decision or question the output must support
- intended audience and deliverable
- definitions and boundaries
- date range, geography, population, and exclusions
- required source types and freshness
- known constraints, permissions, and sensitive-data rules
- target depth or source count
- a stop rule

Use a question framework only when it improves clarity. Choose PICO/PICo,
SPIDER, SPICE, FINER, or a plain concept map based on the question rather than
forcing every task into one framework.

Done when another researcher could tell what is in scope, what is out of scope,
and what evidence would answer the question.

### 2. Design The Search Before Browsing

Turn the question into concept blocks. For each block, list:

- synonyms, acronyms, alternate spellings, and related terms
- controlled vocabulary or subject headings where available
- exclusions and ambiguity terms
- likely primary sources, databases, institutions, authors, and datasets

Use at least two independent discovery paths:

- broad search across multiple query formulations
- targeted search of primary or official sources
- backward citation tracing from strong sources
- forward citation tracing or related-work expansion
- grey-literature, registry, standards, or repository search
- contradictory, failure-mode, or skeptical queries

Do not rely on one query, one database, one ranking, or one search engine.
Record every material query and source boundary.

When Firecrawl is available:

1. Use search for discovery.
2. Use scrape for pages counted as read.
3. Use map to locate relevant pages within a known site.
4. Use crawl only when a bounded site section is itself the research corpus.
5. Use page query or full markdown for load-bearing details that a summary
   cannot safely preserve.

Do not cite a search snippet as if the underlying page was read.

Done when the search plan covers the main concept, adjacent terminology,
primary sources, and at least one path for disconfirming evidence.

### 3. Build A Source Ledger

Track every candidate with a stable ID and one status:

- `candidate`
- `read`
- `excluded`
- `inaccessible`
- `duplicate`
- `superseded`

Count a source as read only when its substantive content was retrieved and
reviewed. Record exclusion reasons. Canonicalize URLs and deduplicate the same
work across mirrors, summaries, preprints, and publisher pages.

For a requested 50-60 source review:

- target 55 unique sources
- allocate category quotas before searching
- prefer diversity of evidence over 55 near-duplicates
- replace failed or thin pages one-for-one
- close with 50-60 relevant, successfully read sources, not candidates

Use [protocol-and-ledgers.md](references/protocol-and-ledgers.md) for the
research brief, search log, source ledger, and evidence matrix formats.

Done when every included or rejected source has a recorded disposition.

### 4. Evaluate Sources Laterally

Judge a source for the claim it supports, not by appearance or domain alone.
Evaluate:

- relevance to the exact question
- proximity to the underlying event, data, or decision
- author or institution expertise
- method and evidence transparency
- independence from other sources
- currency and version
- conflicts, incentives, and funding
- corroboration and traceability to originals

Use lateral reading:

1. Stop before trusting the page.
2. Investigate the source outside its own claims.
3. Find better or independent coverage.
4. Trace quotes, numbers, images, and assertions to their original context.

Prefer primary evidence for factual claims and strong syntheses for landscape
claims. Treat vendor pages, advocacy sources, and expert commentary as
potentially useful but role-limited evidence.

Done when each included source has an explicit reason for inclusion and a
noted limitation.

### 5. Extract Claims, Not Page Summaries

Create an evidence matrix of atomic claims. For each claim record:

- source ID
- claim or finding
- evidence type and method
- population, context, and date
- direct support, indirect support, or contradiction
- limitations and applicability
- confidence
- exact location when verification may be needed later

Paraphrase faithfully. Preserve important numbers, units, denominators,
definitions, and uncertainty. Use short quotations only when wording itself is
material.

Done when every important draft claim can be traced to one or more evidence
rows.

### 6. Appraise By Method

Do not use one universal quality score.

- For reviews: inspect protocol, eligibility criteria, search coverage,
  screening, duplicate handling, risk-of-bias assessment, synthesis method,
  and reporting completeness.
- For quantitative studies: inspect design, sampling, measurement, power,
  missing data, model assumptions, multiplicity, effect sizes, uncertainty,
  robustness, and generalizability.
- For qualitative studies: inspect methodological congruence, sampling logic,
  reflexivity, depth of engagement, analytic process, theme construction,
  negative cases, saturation claims, and contextual transferability.
- For reports and datasets: inspect definitions, provenance, collection
  process, revision policy, completeness, and incentives.
- For online media: inspect provenance, source, date, location, motivation,
  manipulation risk, and independent corroboration.

Separate reporting quality from underlying validity. A complete checklist does
not make a weak study true, and unconventional qualitative work is not weak
merely because it does not mimic quantitative procedures.

Use [method-selection.md](references/method-selection.md) for mode-specific
appraisal and confidence guidance.

Done when evidence weight reflects method, directness, independence, and
applicability rather than source count.

### 7. Synthesize Across Sources

Organize the answer by question, claim, mechanism, or theme, not by source.

For each major finding:

1. State what the evidence supports.
2. Identify the strongest evidence.
3. Explain agreement and disagreement.
4. Test alternative explanations.
5. State boundary conditions and missing evidence.
6. Assign calibrated confidence.

Weight evidence; do not vote by number of links. Ten derivative articles do not
outweigh one strong primary record. Distinguish:

- consensus
- recurring pattern
- plausible inference
- unresolved dispute
- evidence gap

Done when the synthesis explains relationships among sources rather than
repeating their summaries.

### 8. Verify Load-Bearing Claims

Before delivery:

- open every source supporting a central or surprising claim
- prefer the primary source or two genuinely independent sources
- verify current facts against current official evidence
- recalculate important numbers and unit conversions
- confirm names, dates, versions, and citation targets
- check that cited pages actually support the adjacent text
- label inference separately from sourced fact
- retain contradictions instead of smoothing them away

AI output is never evidence. Use AI to expand queries, classify, extract, or
draft, but verify every factual contribution against retrieved sources.
Reject invented or unresolvable citations. Disclose substantive AI use when
the context requires it, preserve human accountability, and never place
confidential research material into an unapproved public model.

Done when a skeptical reviewer can reproduce the central claims from the
recorded evidence.

### 9. Apply The Stop Rule

Stop when all are true:

- the research brief is answered at the required depth
- required source classes and viewpoints are represented
- new searches produce mostly duplicates or no material concepts
- central claims have adequate corroboration
- important disagreements are either resolved or explicitly bounded
- the requested source-count or time boundary is satisfied

Do not use "concept saturation" to hide weak coverage. If a critical source
class is missing, report the gap and stop as partial or blocked.

### 10. Report For Audit And Use

Lead with the answer. Then provide:

- scope and method
- key findings with calibrated confidence
- detailed synthesis
- contradictions and alternative explanations
- limitations and open questions
- source list and exclusions
- rerun inputs or search boundaries

Keep the main response proportional to the decision. Put large source ledgers,
claim matrices, search logs, and extraction tables in appendices or separate
artifacts unless the user asks to see them inline.

Use [report-templates.md](references/report-templates.md) for a research
report, decision memo, literature review, or verification brief.

## Quality Gate

Do not call the work complete unless:

- the scope and stop rule were explicit
- discovery and evidence were kept separate
- all counted sources were actually read
- source exclusions were recorded
- primary and independent sources were prioritized
- central claims map to evidence rows
- uncertainty and disagreement remain visible
- current claims were checked against current sources
- no citation was accepted from AI without verification
- the output answers the user's decision, not merely the topic

## References

- [protocol-and-ledgers.md](references/protocol-and-ledgers.md): reusable
  research brief, search log, source ledger, evidence matrix, and stop memo.
- [method-selection.md](references/method-selection.md): choose research mode,
  source mix, appraisal method, and confidence.
- [report-templates.md](references/report-templates.md): adaptable output
  structures.
- [source-basis.md](references/source-basis.md): the 55-source evidence base
  used to design this skill.
