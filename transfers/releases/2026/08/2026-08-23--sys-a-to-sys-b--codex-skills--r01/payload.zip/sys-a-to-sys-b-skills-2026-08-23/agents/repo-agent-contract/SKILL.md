---
name: repo-agent-contract
description: Use when setting up or auditing repo-local agent instructions, issue tracker rules, triage labels, domain docs, ADR paths, Obsidian links, or founder-log memory routing
---

# Repo Agent Contract

## Purpose

Create the small repo-local contract that lets agents work consistently without rediscovering project memory every session.

This adapts Matt Pocock's repo setup pattern to this machine's Codex, Obsidian, founder-log, Linear, GitHub, and local-markdown workflows.

## Explore First

Read what exists before editing:

- `AGENTS.md`, `CLAUDE.md`, `README*`, `CONTEXT.md`, `CONTEXT-MAP.md`.
- `docs/agents/`, `docs/adr/`, `.scratch/`.
- `founder_logs/`, `CONTEXT_INDEX.md`, `INDEX_CURRENT.md`, `_ACTIVE.md`.
- Git remotes and branch state.
- Obsidian project note under `D:/Balcony/Obsidian/02-Projects/` when relevant.

## Contract Files

Prefer `docs/agents/` for repo-local agent configuration:

- `issue-tracker.md`: GitHub, Linear, Jira, local markdown, or other.
- `triage-labels.md`: canonical states and the real tracker labels/statuses.
- `domain.md`: where `CONTEXT.md`, `CONTEXT-MAP.md`, and ADRs live.
- `memory-routing.md`: repo-local logs, founder logs, Obsidian note, and daily-note writeback.

Update `AGENTS.md` with a short `## Agent Contract` block pointing to these files. If `CLAUDE.md` is the only existing instruction file, update that instead. If both exist, keep them consistent without duplicating long content.

## Canonical Triage States

Use these names internally, even if the tracker uses different strings:

- `needs-triage`: maintainer evaluation required.
- `needs-info`: blocked on reporter/user input.
- `ready-for-agent`: specified enough for an agent to pick up.
- `ready-for-human`: requires human judgment, access, or manual action.
- `wontfix`: intentionally not actioned.

## Memory Routing

Use the Obsidian memory contract:

- Code, config, tests, and live infra are implementation truth.
- `founder_logs/` hold chronology, validation evidence, and decisions.
- Repo `AGENTS.md` bootstraps agents into project context.
- Obsidian is the routing and synthesis layer.

Do not copy long founder-log content into Obsidian. Link and summarize.

## Ask Before Writing

If the tracker, labels, or domain-doc layout is ambiguous, present the findings and ask only the blocking question. Do not create a new tracker convention silently.

## Git Safety

Never stage, commit, push, reset, clean, or rewrite branches unless the user explicitly asks. Contract setup may edit files; git publication is a separate permission.
