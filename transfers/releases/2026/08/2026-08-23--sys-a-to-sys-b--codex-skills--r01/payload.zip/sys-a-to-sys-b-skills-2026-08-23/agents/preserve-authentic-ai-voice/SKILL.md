---
name: preserve-authentic-ai-voice
description: Use when AI has assisted research, outlining, drafting, rewriting, editing, or project storytelling and the final work must retain the author's real voice, judgment, evidence, contribution, attribution, disclosure, and accountability; also use to remove generic AI prose and audit claims about completed work, outcomes, or impact.
---

# Preserve Authentic AI Voice

## Core Principle

Keep human ownership of:

```text
origin + judgment + contribution + verification + accountability
```

AI may expand options, organize material, criticize reasoning, or assist
expression. It must not become the hidden source of experience, evidence,
judgment, or responsibility.

Voice is a decision pattern, not a banned-word list. Preserve what the author
notices, doubts, values, measures, refuses to claim, and can defend.

## Route The Work

Use:

- `conduct-research` when factual support or citations remain unverified
- `writing-fragments` to recover the author's raw observations and phrases
- `writing-beats` to restore the author's intended argument sequence
- `write-impactful-articles` when the article itself lacks reader impact,
  coherence, or transfer

Do not use AI-detector scores as evidence of authorship. Do not distort a
writer's legitimate dialect or make prose artificially quirky to appear human.

## Workflow

### 1. Establish The Human Source

Before substantial AI drafting, capture:

- provisional thesis
- direct observations or lived experience
- concrete examples and decisions
- phrases the author naturally uses
- values and tradeoffs the author foregrounds
- claims the author refuses to make
- current uncertainty and open questions

If editing an existing draft, recover these from notes, interviews, messages,
earlier drafts, or a short author interview. Do not invent missing experience.

### 2. Classify AI Assistance

Use three zones:

| Zone | Examples | Required control |
|---|---|---|
| Green | spelling, formatting, duplicate detection, query variants | review for changed meaning |
| Amber | outlines, summaries, examples, transitions, rewrites, thesis options | independently verify and substantially judge |
| Red | invented experience, fabricated evidence, unverified citations, conclusions the author cannot defend | reject |

Treat substantive AI output as a candidate, never a default.

### 3. Preserve Decision-Point Ownership

The author must control:

- problem framing
- definitions
- evidence thresholds
- source selection
- disagreement resolution
- examples
- causal language
- disclosure
- final approval

Ask AI for options, objections, gaps, compression, or alternate formulations.
Do not ask it to manufacture authority, emotion, virality, or thoughtfulness.

### 4. Separate Evidence From Generated Prose

Maintain:

1. an evidence ledger containing source, method, finding, limitation, and exact
   support
2. a draft containing the author's claims and explanation

Never treat AI-generated prose or citations as evidence. Open and verify every
source supporting a factual or consequential claim.

### 5. Run The Voice Audit

For every section, ask:

- Is this a distinction the author actually makes?
- Is the example real, sourced, or clearly labeled hypothetical?
- Would the author say this aloud and defend it under questioning?
- Did the draft remove cultural, domain, or experiential specificity?
- Did a generic transition hide the real logical relationship?
- Did smooth language increase confidence beyond the evidence?
- Is uncertainty expressed where the author genuinely has it?

Restore the author's chosen objects, actors, decisions, metrics, boundaries,
and consequences.

### 6. De-Genericize Without Performing Humanity

For each paragraph:

1. replace abstraction with the exact object, actor, decision, or metric
2. remove throat-clearing and ceremonial transitions
3. state the real logical relationship
4. restore a concrete observation or source-grounded example
5. add the boundary required by the evidence
6. remove any sentence the author cannot explain or defend

Inspect common filler such as "delve", "navigate the landscape", "unlock the
potential", "a testament to", and "it is important to note". Remove it when it
does no work; do not ban accurate words merely because models often use them.

### 7. Verify Claims And Reasoning

For every load-bearing claim:

- open the source
- confirm identity, date, method, and exact support
- prefer primary evidence
- reproduce important calculations
- inspect whether correlation became causation
- preserve sample and context boundaries
- check contradictory evidence
- separate fact from inference

True premises can still support a false conclusion. Verify the reasoning bridge,
not only names and numbers.

### 8. Represent Contribution Honestly

Separate:

- **activity:** what was done
- **output:** what was produced
- **outcome:** what changed
- **impact:** broader or sustained consequential change with credible
  attribution

Describe the author's role with specific verbs such as designed, implemented,
investigated, analyzed, validated, coordinated, reviewed, or documented.

Do not collapse team work into "I built". Do not minimize a real contribution
when role and evidence support it.

For project narratives, include:

1. context
2. observable problem
3. actual role
4. method and rejected alternatives
5. evidence and result
6. collaborators and external factors
7. limitations
8. next test or step

### 9. Calibrate Outcome And Impact Language

Require baselines, denominators, periods, definitions, exclusions, and
comparison conditions.

Use:

- `caused` only with credible causal support
- `increased after` for temporal observation
- `was associated with` for association
- `contributed to` when several factors acted
- `supported` when work enabled another result
- `coincided with` when attribution is weak
- `illustrates` for a case
- `suggests` for exploratory evidence

Treat words such as impactful, transformative, robust, secure, scalable,
accurate, production-ready, end-to-end, and state-of-the-art as claims that
need definitions and proof.

Remove extraordinary language such as revolutionary, groundbreaking,
game-changing, flawless, guaranteed, solved, or 10x unless extraordinary
evidence genuinely supports it.

### 10. Write Proportional Disclosure

Disclose material AI assistance at the task level. State:

- what AI did
- what the human did
- what was independently verified
- who owns the final judgment and accountability

Example:

```text
I used generative AI to test alternative outlines, identify possible
counterarguments, and edit selected passages for clarity. I selected and read
the sources, determined the claims and conclusions, verified the citations and
factual statements, rewrote the final text, and accept responsibility for it.
```

Follow publisher, employer, client, legal, privacy, and contractual rules. Do
not place confidential material in an unapproved model.

## Output Contract

When revising a draft:

- preserve the author's supported thesis and real experience
- return the revised text
- identify claims still needing verification
- provide a proportional disclosure when relevant
- flag contribution or impact wording that remains unsupported

When auditing:

- lead with authorship, evidence, or attribution failures
- distinguish generic style from substantive loss of ownership
- do not accuse the author of AI use based on vocabulary or detector scores
- give concrete revisions tied to evidence and author intent

## Quality Gate

Do not call the work authentically human and publication-ready unless:

- the author can explain and defend every major claim
- the thesis and verdict reflect human judgment
- no experience, quotation, result, or citation was invented
- AI-generated citations were independently opened and checked
- examples and language preserve real specificity
- collaborators are credited by actual role
- activity, output, outcome, and impact are separated
- material AI assistance is disclosed when policy or reader judgment requires it
- confidential information remained protected
- the author performed final approval and accepts accountability

Read [voice-authorship-and-impact-audit.md](references/voice-authorship-and-impact-audit.md)
for reusable interview questions, claim-language checks, disclosure patterns,
and the pre-publication audit.

