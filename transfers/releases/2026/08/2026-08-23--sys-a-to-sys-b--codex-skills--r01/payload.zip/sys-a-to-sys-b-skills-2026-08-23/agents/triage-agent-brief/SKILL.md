---
name: triage-agent-brief
description: Use when triaging issues, PRs, Linear tickets, local markdown tasks, or requests into agent-ready briefs with acceptance criteria and scope boundaries
---

# Triage Agent Brief

## Goal

Move a request from vague input to one clear state and, when ready, write a durable brief an agent can execute later.

Use `repo-agent-contract` first if the repo has no tracker or label/status mapping.

## States

Each triaged item should have one state:

- `needs-triage`: not evaluated yet.
- `needs-info`: blocked on specific missing information.
- `ready-for-agent`: agent can act without hidden context.
- `ready-for-human`: requires judgment, credentials, manual verification, or ownership.
- `wontfix`: rejected or already handled.

Also classify as `bug`, `enhancement`, `task`, `research`, or `ops`.

## Triage Process

1. Read the full request, comments, labels/status, linked docs, and prior notes.
2. Search the codebase and docs by domain concept, not only exact wording.
3. Check whether the behavior already exists or was previously rejected.
4. For bugs, try to reproduce or identify the missing reproduction artifact.
5. Recommend state and category with evidence.
6. If ready, write the agent brief.
7. If not ready, ask specific questions or document why it needs a human.

## Agent Brief Template

```markdown
## Agent Brief

**Category:** bug / enhancement / task / research / ops
**Summary:** one-line desired outcome

**Current behavior:**
What happens now, or what is missing.

**Desired behavior:**
What should be true after the work is complete, including edge cases.

**Key interfaces:**
- Public type, endpoint, CLI command, workflow, adapter, config shape, or UI path that matters.

**Acceptance criteria:**
- [ ] Specific, testable criterion.
- [ ] Specific, testable criterion.

**Out of scope:**
- Adjacent work that should not be included.

**Verification:**
- Command, test level, manual check, or evidence expected.
```

## Durable Brief Rules

- Prefer behavior and interfaces over file paths.
- Avoid line numbers.
- Include acceptance criteria and out-of-scope items.
- Capture blockers explicitly.
- Do not invent emails, credentials, or external access.
- Mark AI-generated tracker comments clearly when posting externally.

## Done

Triage is done when the item has a state, category, rationale, and either a ready brief or a precise reason it is not ready.
