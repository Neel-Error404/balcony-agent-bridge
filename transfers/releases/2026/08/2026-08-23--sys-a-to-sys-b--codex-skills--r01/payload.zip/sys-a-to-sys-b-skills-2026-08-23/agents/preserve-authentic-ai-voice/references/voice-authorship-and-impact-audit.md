# Voice, Authorship, And Impact Audit

## Contents

1. Author interview
2. Voice fingerprint
3. Verification ledger
4. Contribution and impact checks
5. Disclosure patterns
6. Pre-publication audit
7. Research basis

## Author Interview

Use these questions when the draft lacks clear human source material:

1. What happened that made you care about this?
2. What did you initially believe?
3. What evidence or failure changed your mind?
4. Which tradeoff matters most?
5. What would you refuse to claim?
6. What example could only come from your experience?
7. Which part of the conclusion remains uncertain?
8. What should a skeptical reader challenge?
9. What did collaborators contribute?
10. What decision should become easier after reading?

Use the answers as source material. Do not fabricate answers from the draft.

## Voice Fingerprint

Voice includes:

- recurring distinctions
- evidence standards
- characteristic doubts
- moral and practical priorities
- treatment of affected people
- domain-specific objects and examples
- degree and placement of emotion
- preferred directness
- boundaries on certainty
- claims the author declines to make

Surface rhythm and vocabulary are secondary. Preserve the decision pattern
before imitating sentence style.

## Verification Ledger

Use this structure:

| Claim | Type | Required support | Verification | Boundary |
|---|---|---|---|---|
| AI reduced completion time | empirical | primary experiment and task context | method and result opened | short professional tasks |
| Our system improved accuracy | project result | metric, baseline, test set, date | calculation reproduced | tested environment only |
| This changed user behavior | outcome | behavior measure and comparison | time window checked | other changes considered |
| This was transformative | impact | sustained attributed change | usually unsupported | replace or define |

For every citation:

- open the source
- confirm title, author, date, and venue
- locate exact support
- record limitation
- prefer the primary source
- verify current links and policies near publication

## Contribution And Impact Checks

### Contribution verbs

Use specific verbs when accurate:

- designed
- implemented
- investigated
- analyzed
- validated
- tested
- led
- coordinated
- reviewed
- documented
- co-authored
- contributed

### Evidence verbs

- measured
- observed
- compared
- reproduced
- evaluated
- audited
- verified
- sampled
- estimated
- recorded

### Calibrated verbs

- suggests
- indicates
- is consistent with
- was associated with
- contributed to
- supported
- coincided with
- under these conditions
- within this sample
- based on the available evidence

### Claims requiring definition

Treat these as claims, not decoration:

- impactful
- transformative
- innovative
- scalable
- robust
- reliable
- secure
- accurate
- efficient
- accessible
- inclusive
- production-ready
- autonomous
- real-time
- end-to-end
- best-in-class
- state-of-the-art

Ask:

- compared with what?
- measured how?
- under which conditions and load?
- for whom?
- for how long?
- what failed?

### Extraordinary claims

Remove unless extraordinary evidence supports them:

- revolutionary
- groundbreaking
- game-changing
- unprecedented
- world-changing
- solved
- guaranteed
- flawless
- seamless
- human-level
- democratized
- 10x
- industry-leading
- paradigm-shifting

Replace adjectives with mechanism, measurement, attribution, and limitation.

## Disclosure Patterns

### Editorial assistance

```text
I used generative AI to test alternative outlines, identify possible
counterarguments, and edit selected passages for clarity. I selected and read
the sources, determined the claims and conclusions, verified the citations and
factual statements, rewrote the final text, and accept responsibility for it.
```

### Heavier drafting assistance

```text
A language model produced preliminary summaries and draft passages for
specified sections. I checked each summary against the original source,
removed unsupported claims, substantially rewrote the prose, and determined
the final argument. The model was not used as a source.
```

Adapt disclosure to the actual tasks. Do not claim controls that were not
performed.

## Pre-Publication Audit

### Authorship

- The author can explain and defend every major claim.
- The thesis and verdict reflect the author's judgment.
- No personal experience, quotation, result, or citation was invented.
- Collaborators are credited by actual role.
- The author retains final veto and accountability.

### Evidence

- Every citation opens and supports the adjacent claim.
- Primary sources were used where available.
- Contradictory evidence is represented.
- Causal language matches study design.
- Metrics include baselines, denominators, periods, and exclusions.

### Voice

- Examples are real, sourced, or labeled hypothetical.
- Prose contains the author's distinctions, priorities, and uncertainty.
- Generic transitions and unsupported intensifiers are removed.
- Editing has not erased legitimate dialect or cultural specificity.
- The draft does not perform eccentricity to appear human.

### AI Governance

- Confidential material was protected.
- Material AI tasks were recorded.
- Model output was treated as untrusted input.
- Detector scores were not used as proof.
- Disclosure is specific and policy-compliant.

### Impact

- Activity, output, outcome, and impact are separated.
- The author's contribution is distinct from the team's.
- "Impact" is supported or replaced by a narrower term.
- Limitations appear near the claims they limit.
- The next step follows from the evidence.

## Research Basis

This skill was derived from the governed research package:

```text
D:\Balcony\azureVM setup\docs\research\impactful-writing-ai-authorship
```

The package includes a 32-source paper on human-AI authorship, voice,
verification, disclosure, contribution, and impact portrayal, plus its source
ledger and claim-evidence matrix.

