---
name: write-impactful-articles
description: Use when planning, drafting, restructuring, or auditing an evidence-led article, essay, proof-of-work post, technical explanation, research synthesis, or thought-leadership piece that must be coherent, thought-provoking, memorable, trustworthy, and useful rather than merely polished or attention-grabbing.
---

# Write Impactful Articles

## Core Principle

Design for a defensible change in the reader:

```text
attention -> orientation -> comprehension -> calibrated belief
          -> memory -> transfer -> useful action or conversation
```

The article fails where this chain breaks. Do not optimize clicks, fluency,
emotion, or style independently from truth and reader use.

## Route The Work

Use the surrounding skills when applicable:

1. Use `conduct-research` when claims still need discovery or verification.
2. Use `writing-fragments` when the input is messy notes or source material.
3. Use `writing-beats` when the argument has not yet been sequenced.
4. Use this skill to design and draft the complete article.
5. Use `preserve-authentic-ai-voice` when AI materially assisted the work or
   the author needs a voice, disclosure, contribution, or impact-claim audit.

Do not manufacture an argument from thin evidence. Return to research when the
article needs stronger claims than the evidence permits.

## Workflow

### 1. Freeze The Reader Contract

Write:

- the specific reader, situation, decision, and constraint
- the change the article should produce
- the central question
- what the article will and will not cover
- the evidence threshold

Replace generic audiences such as "people interested in AI" with a reader in a
recognizable situation.

### 2. Write The Argument Triad

State three sentences:

- **Thesis:** the defensible central answer
- **Tension:** the plausible alternative, contradiction, or tradeoff
- **Stakes:** what changes if the thesis is accepted

Reject topic-only articles. A list of relevant facts is not an argument.

### 3. Build The Heading-Only Spine

Make every heading perform one argumentative job:

- define
- establish stakes
- explain mechanism
- present evidence
- distinguish cases
- answer an objection
- show application
- synthesize implications

Use claim-bearing headings. A reader scanning only the title and headings
should recover the direction and logic of the article.

### 4. Draft In Evidence Units

Use this unit at paragraph and section scale:

1. **Claim:** what the reader should accept
2. **Evidence:** why it deserves acceptance
3. **Reasoning:** how the evidence supports this claim
4. **Boundary:** where the conclusion may not hold
5. **Implication:** what changes for the reader

Attach evidence to the claim it supports. Keep causal verbs, denominators,
baselines, uncertainty, and source limitations intact.

### 5. Create Coherent Flow

Audit five forms of coherence:

- sentence-to-sentence connection
- clear referents and stable terminology
- explicit causal and logical relationships
- necessary section order
- continued service to the reader contract

Write transitions that name the relationship, not decorative connectors:

```text
The evidence establishes X. It does not yet establish Y.
```

Cut tangents unless they supply evidence, mechanism, contrast, necessary
context, or a clearly marked future question.

### 6. Use Narrative Under Evidence Control

Use stories and cases for experience, stakes, and mechanism. Use broader
evidence for frequency and magnitude.

For every case:

- label it as evidence, example, illustration, or counterexample
- state what makes it representative or unrepresentative
- connect it to the mechanism
- avoid invented detail

Do not let a memorable story carry a claim it cannot prove.

### 7. Earn Thoughtfulness

Create thought through a genuine model conflict, not rhetorical decoration.

For each central claim:

1. state the strongest competing explanation
2. identify what it explains well
3. show where it becomes incomplete
4. state what evidence would change the conclusion

Ask only questions the evidence has earned. Answer what can be answered and
preserve consequential uncertainty.

### 8. Edit Clarity And Calibration Together

Reduce avoidable decoding without erasing important distinctions.

- use familiar words when meaning is preserved
- define necessary technical terms
- keep one term for one concept
- remove throat-clearing and unsupported intensifiers
- use `caused`, `associated with`, `suggests`, or `illustrates` according to
  the evidence

Clear prose can make weak claims feel true. Check warrant separately from
readability.

### 9. Design For Digital Reading

Provide enough information scent for selective readers:

- descriptive title
- early thesis
- claim-bearing headings
- orientation before dense evidence
- summary after complex sections
- visible source links
- visuals only when they compare, reveal scale, show sequence, expose
  structure, locate uncertainty, or provide evidence

Do not fragment a connected argument into disconnected cards or slogans.

### 10. End With Transfer

Resolve the opening tension and leave the reader with:

- a governing principle
- a distinction or diagnostic
- a proportionate next action
- a consequential open question when necessary

The conclusion should make the model portable, not repeat every section.

## Editing Passes

Run in this order:

1. **Relevance:** remove material that does not help this reader.
2. **Structure:** make every section earn the next one.
3. **Evidence:** trace and bound every important claim.
4. **Truth:** audit causal language, baselines, examples, and counterevidence.
5. **Coherence:** repair missing logical bridges and unstable terms.
6. **Reader:** test comprehension, trust, memory, and intended use.
7. **Voice:** invoke `preserve-authentic-ai-voice` when appropriate.

Do not polish prose before the argument and evidence survive these checks.

## Output Contract

When producing an article, return:

- title
- optional subtitle
- article body with claim-bearing headings
- source links or citations where required
- disclosure when AI use is material
- optional short audit note listing unresolved evidence or impact limitations

When auditing an existing article, lead with the highest-risk failures:

- unsupported or overstated claims
- unclear reader contract
- broken argument progression
- evidence-story confusion
- missing counterargument
- generic conclusion without transfer

Then provide a revised structure or text.

## Quality Gate

Do not call the article complete unless:

- the reader, decision, and intended change are specific
- thesis, tension, and stakes are visible
- headings reconstruct the argument
- central claims have evidence, reasoning, boundaries, and implications
- narrative does not substitute for prevalence or magnitude evidence
- the strongest alternative is treated fairly
- confidence matches the evidence
- the ending transfers a usable model or decision
- a zero in evidence or relevance is not hidden by style

Read [article-design-rubric.md](references/article-design-rubric.md) for the
scoring rubric, failure patterns, and pre-publication audit.

