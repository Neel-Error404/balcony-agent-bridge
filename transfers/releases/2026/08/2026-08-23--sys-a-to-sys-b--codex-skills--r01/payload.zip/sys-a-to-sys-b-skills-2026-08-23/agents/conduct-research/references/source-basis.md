# Source Basis

This skill was synthesized from 55 unique sources retrieved through full-page
Firecrawl requests and reviewed through substantive extracted summaries on
2026-08-07. Every accepted source returned HTTP 200. Two initially selected
pages were excluded for insufficient methodological content and replaced
one-for-one.

## Corpus

| Category | Sources |
| --- | ---: |
| Research question design | 5 |
| Search and discovery | 6 |
| Source evaluation | 5 |
| Review methods | 7 |
| Evidence appraisal | 6 |
| Qualitative methods | 4 |
| Open science | 6 |
| Data provenance | 4 |
| Verification and OSINT | 5 |
| Synthesis and writing | 4 |
| AI-assisted research | 3 |
| **Total** | **55** |

The corpus includes peer-reviewed methods papers, PRISMA, Cochrane, JBI,
GRADE, CDC, Center for Open Science, university evidence-synthesis and
reproducibility guidance, Civic Online Reasoning, First Draft, Bellingcat,
literature-review methods, and empirical research on AI hallucinations.

See [source-basis.csv](source-basis.csv) for the complete accepted URL ledger
and [source-exclusions.csv](source-exclusions.csv) for recorded exclusions.

## Main Convergences

The corpus repeatedly supports these design choices:

1. Formulate an answerable question and explicit eligibility boundary before
   committing to a search.
2. Search through multiple query formulations, databases, citation paths, and
   grey-literature sources.
3. Treat search as a reproducible method and peer-review important strategies.
4. Evaluate sources laterally and trace claims to original context.
5. Separate source discovery, source inclusion, evidence extraction, and claim
   synthesis.
6. Appraise evidence with method-specific criteria rather than one universal
   score.
7. Preserve researcher judgment and reflexivity instead of disguising it as
   mechanical neutrality.
8. Record data, code, versions, decisions, and exclusions throughout the
   workflow.
9. Synthesize by claim and theme, weight evidence by quality and independence,
   and retain disagreement.
10. Use AI as an assistive tool, never as evidence; verify its citations and
    disclose substantive use.

## Important Tensions Preserved

- Comprehensive search competes with time and precision. The skill therefore
  requires a planned stop rule rather than unlimited browsing.
- Formal checklists improve transparency but can become ritualized. The skill
  separates reporting completeness from validity.
- Preregistration reduces undisclosed analytical flexibility but must remain
  adaptable for exploratory, longitudinal, and qualitative work.
- Scoping reviews map evidence and may omit formal critical appraisal;
  systematic reviews answer narrower questions and require stronger appraisal.
- Qualitative rigor depends on methodological congruence and reflexivity, not
  on copying quantitative ideas of objectivity.
- Large source counts can create false confidence. The skill counts only
  successfully read, relevant, non-duplicate sources and weights independent
  evidence rather than links.
