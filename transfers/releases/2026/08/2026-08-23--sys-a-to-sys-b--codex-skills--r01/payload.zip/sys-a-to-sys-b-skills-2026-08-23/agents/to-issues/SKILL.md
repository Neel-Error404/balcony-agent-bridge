---
name: to-issues
description: Use when turning a plan, PRD, spec, conversation, handoff, or large task into independently executable issues or tickets
---

# To Issues

## Core Pattern

Break work into tracer-bullet vertical slices. Each issue should deliver a narrow complete path through the system, not a horizontal layer.

Use `repo-agent-contract` to find the tracker convention. Use `triage-agent-brief` for ready-for-agent issue bodies.

## Process

1. Gather source material: conversation, PRD, spec, branch, issue, docs, and project memory.
2. Identify the user-visible or operational outcomes.
3. Find any prefactor needed to make later slices simpler.
4. Draft vertical slices in dependency order.
5. Ask for approval on granularity and blockers before publishing.
6. Create or prepare issues only after approval.

## Slice Rules

Each slice should:

- Be demoable or verifiable alone.
- Cross the necessary layers end to end.
- Have a clear acceptance test.
- Avoid stale file-path instructions.
- Name blockers explicitly.
- Avoid bundling unrelated cleanup.

## Issue Body

```markdown
## What to build

Describe the end-to-end behavior or operational result.

## Acceptance criteria

- [ ] Specific criterion.
- [ ] Specific criterion.

## Blocked by

None, or linked issue names.

## Out of scope

Adjacent work to avoid.

## Verification

Expected tests, commands, or evidence.
```

## Done

The breakdown is done when every issue is independently understandable, blockers are explicit, and the first executable slice is obvious.
