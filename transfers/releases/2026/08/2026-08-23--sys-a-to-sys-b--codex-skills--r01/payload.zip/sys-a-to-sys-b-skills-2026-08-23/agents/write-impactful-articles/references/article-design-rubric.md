# Article Design Rubric

## Contents

1. Scoring rubric
2. Heading and paragraph checks
3. Common failure patterns
4. Reader test
5. Research basis

## Scoring Rubric

Score each dimension from 0 to 3.

| Dimension | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Reader relevance | Generic | Audience named | Situation clear | Decision and constraint clear |
| Thesis | Missing | Topic only | Defensible claim | Claim plus tension and stakes |
| Structure | List | Loose sequence | Clear hierarchy | Necessary argumentative progression |
| Evidence | Assertion | Citations present | Evidence matched to claims | Corroborated, weighted, and bounded |
| Coherence | Abrupt | Locally smooth | Section logic visible | Reader can reconstruct the model |
| Narrative | Decorative | Vivid but weakly linked | Relevant illustration | Mechanism-bearing and bounded |
| Counterargument | None | Token caveat | Strong alternative addressed | Conditions for changing conclusion stated |
| Calibration | Hype | Generic hedging | Mostly matched | Causal and uncertainty language audited |
| Memorability | Slogan only | Repetition | Clear synthesis | Portable model with justified stakes |
| Transfer | No next step | Generic call | Relevant application | Reader can diagnose or decide independently |

A high total cannot compensate for zero evidence or zero reader relevance.

## Heading Check

Read only the title and headings. Confirm they reveal:

- the reader problem
- the thesis
- the mechanism
- the important distinction or tension
- the strongest objection
- the practical implication

Replace headings such as "Why It Matters", "Key Insights", and "The Future"
with claims or intellectual jobs.

## Paragraph Check

Label each paragraph:

```text
claim | evidence | reasoning | boundary | implication
definition | example | objection | transition
```

A paragraph may perform several connected roles, but every role must be
identifiable. Remove passages whose absence breaks nothing.

## Common Failure Patterns

### Attention without trust

Symptoms:

- headline stronger than evidence
- manufactured mystery
- withheld trivial answer

Correction: create a relevant, closable information gap and keep the promise.

### Smooth list without argument

Symptoms:

- relevant facts
- generic headings
- no contestable thesis

Correction: write thesis, tension, and stakes; rebuild the heading-only spine.

### Citation without reasoning

Symptoms:

- study appears after claim
- reader must infer why it supports the claim
- limitation disappears

Correction: state the reasoning bridge and boundary explicitly.

### Story mistaken for prevalence

Symptoms:

- one vivid case carries a population claim
- emotional detail replaces measurement

Correction: label the case and add broader evidence for frequency or magnitude.

### Thought-provoking by performance

Symptoms:

- rhetorical questions with no decision
- weak straw man
- controversy added for energy

Correction: expose a genuine model conflict and answer the strongest alternative.

### Clarity that overstates certainty

Symptoms:

- causal verbs exceed study design
- qualifiers removed during editing
- easy prose makes an inference sound settled

Correction: audit warrant separately from readability.

### Digital fragmentation

Symptoms:

- every idea isolated as a card or callout
- reasoning cannot accumulate
- headings become slogans

Correction: preserve connected paragraphs and use visual structure for
orientation, not disassembly.

### Conclusion without transfer

Symptoms:

- summary repeats sections
- generic inspiration or call to action
- no usable diagnostic

Correction: resolve the tension and leave a portable model, decision, or test.

## Reader Test

Ask representative readers:

1. What do you think the thesis is?
2. Where did you lose the structure?
3. Which claim do you remember?
4. Which claim do you distrust?
5. What changed in your understanding?
6. Where could you apply the model?
7. What would you do differently?

Do not ask only whether they liked the article.

## Research Basis

This skill was derived from the governed research package:

```text
D:\Balcony\azureVM setup\docs\research\impactful-writing-ai-authorship
```

The package includes a 31-source paper on article impact, source ledger,
claim-evidence matrix, search log, protocol, and stop memo. Its central model
is that impact depends on attention, orientation, comprehension, calibrated
belief, memory, transfer, and proportionate action.

