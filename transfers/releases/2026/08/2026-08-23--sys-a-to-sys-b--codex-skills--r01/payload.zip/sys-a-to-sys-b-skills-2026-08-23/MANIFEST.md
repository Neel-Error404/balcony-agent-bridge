# Transfer Manifest

## Included Codex skills (18)

| Skill | Files | Bytes | Aggregate source-tree SHA-256 |
|---|---:|---:|---|
| `architecture-review-html` | 1 | 1,851 | `5D3558D76D0EFFD6FB3BB4921F44CEB850AA54A94B34C268DC1E60E50611C8A3` |
| `conduct-research` | 8 | 31,165 | `C8AB541ABBD90332D55A0DBA4D9ECEFCEDAEDEBF24E286E1409A183F20E867C4` |
| `eli5` | 2 | 3,274 | `D247016C118C232D053ABEAB542B9DC5DC71EF7916812E2C664308F2CAF88464` |
| `linear` | 1 | 8,486 | `F3684B16C1259991B1A832985A86AB606D4B2D628BF523E3AC0385A0366F9A1F` |
| `vercel-deploy` | 6 | 17,250 | `F321D4E146F2CAE96E815F93E995FA8E4FDEF0426980097FCA0C1202AD747B70` |
| `writing-great-skills` | 1 | 3,277 | `E8E3352D5E0BA5BA0B5CF810FD5EF0F19541EB8D69B87A6D51146155CC385C9A` |
| `onboard-new-user` | 1 | 12,988 | `28C7E18E03B93BC5B7A44A914DEA5404EFE5FE07D91443BC6C39BBEB7CA8067E` |
| `orchestrate` | 2 | 5,068 | `8BB53DBC1160D6D71192FDEE666C826BB05FD7E0E8443FCF8CABFB307577C7E6` |
| `preserve-authentic-ai-voice` | 3 | 14,748 | `A7ADFD4F8C04CAAB81D033D5363353CC17A5C2C54AAB41E1A93EFDB3E0312E79` |
| `repo-agent-contract` | 1 | 2,604 | `C6469D8A7C473D65CB08B6DE9C1CF99C3A9978D9C7A74E18E84F27978C185933` |
| `stay-on-track` | 4 | 18,390 | `879453B3537F353CF1CDCEDEAA6CA449EB6725BF4F7634E113338A7DD9114228` |
| `symphony-controller` | 1 | 4,449 | `D96F14B735FEE69DBB88AABA78C4EC88EED816A329A891D9348A79C8C6D16621` |
| `symphony-setup` | 1 | 4,246 | `F81BC2CC9BC5F7D63BC9F650CA80221643FA2B041D325CE99DB53A531C216B5B` |
| `to-issues` | 1 | 1,550 | `EF41DFC5ADCD27805BE3677C7E97E82F79654C4636EA759B6DE608E50BE73222` |
| `tracker-setup` | 1 | 3,001 | `99D8C44C662C6E1E6C958DB134B1BAF2042214CB55866CA13EC6DB4BFC8B54CD` |
| `triage-agent-brief` | 1 | 2,429 | `FCA4B2F55A0A6B811714FDA3FFAB0782F084DEFB077C197BC1BA13AB5E37CA83` |
| `voiceai-release-readiness` | 2 | 14,494 | `DD80D4C359C230CFBA9064A430F9D595EBF64A4C61A82E32268389902ED6D786` |
| `write-impactful-articles` | 3 | 11,955 | `D0D31A8224F04F992D50D0F7B292F1410B9BE621794D0D82D1C8DA93FE8A12EC` |

## Included Agents mirrors (8)

| Skill | Files | Bytes | Aggregate source-tree SHA-256 | Matches Codex |
|---|---:|---:|---|---|
| `architecture-review-html` | 1 | 1,851 | `5D3558D76D0EFFD6FB3BB4921F44CEB850AA54A94B34C268DC1E60E50611C8A3` | yes |
| `conduct-research` | 8 | 31,165 | `C8AB541ABBD90332D55A0DBA4D9ECEFCEDAEDEBF24E286E1409A183F20E867C4` | yes |
| `writing-great-skills` | 1 | 3,277 | `E8E3352D5E0BA5BA0B5CF810FD5EF0F19541EB8D69B87A6D51146155CC385C9A` | yes |
| `preserve-authentic-ai-voice` | 3 | 14,748 | `A7ADFD4F8C04CAAB81D033D5363353CC17A5C2C54AAB41E1A93EFDB3E0312E79` | yes |
| `repo-agent-contract` | 1 | 2,604 | `C6469D8A7C473D65CB08B6DE9C1CF99C3A9978D9C7A74E18E84F27978C185933` | yes |
| `to-issues` | 1 | 1,550 | `EF41DFC5ADCD27805BE3677C7E97E82F79654C4636EA759B6DE608E50BE73222` | yes |
| `triage-agent-brief` | 1 | 2,429 | `FCA4B2F55A0A6B811714FDA3FFAB0782F084DEFB077C197BC1BA13AB5E37CA83` | yes |
| `write-impactful-articles` | 3 | 11,955 | `D0D31A8224F04F992D50D0F7B292F1410B9BE621794D0D82D1C8DA93FE8A12EC` | yes |

Transferred skill files before bundle metadata: 59  
Transferred skill bytes before bundle metadata: 230,804

## Source/provenance findings for the six previously uncertain skills

| Skill | Local evidence |
|---|---|
| `architecture-review-html` | Standalone SYS-A local skill; no source URL, licence, author metadata, or matching installed plugin-cache path was found. |
| `conduct-research` | Standalone SYS-A local skill with bundled references; no source URL, licence, author metadata, or matching installed plugin-cache path was found. |
| `eli5` | Standalone SYS-A local skill; no source URL, licence, author metadata, or matching installed plugin-cache path was found. |
| `linear` | SYS-A-specific skill for the `Algo_mod` / `SurveyAI` Linear workspace; no plugin-cache match or upstream repository declaration was found. |
| `vercel-deploy` | Contains `LICENSE.txt` with MIT copyright (c) 2026 Vercel. No matching installed plugin-cache path was found. The local `SKILL.md` also contains SYS-A-specific release guardrails, so this archive preserves the exact local copy. |
| `writing-great-skills` | Standalone SYS-A local skill; no source URL, licence, author metadata, or matching installed plugin-cache path was found. |

These findings are limited to current SYS-A files and installed plugin-cache
paths. They do not prove that no external repository exists.

## Safety scan

- Selected trees had no reparse points or junctions.
- No credential-shaped value matched the local scan for private keys, common
  cloud/API token formats, password assignments, access tokens, or refresh
  tokens.
- No selected filename matched environment, credential, cookie, token, auth,
  browser-data, database, ZIP, or backup patterns.
- `stay-on-track/scripts/__pycache__/score_prompt.cpython-313.pyc` was excluded
  as generated cache material.
- Public Matt Pocock skill directories were not copied.

## Validation notes

- 26 packaged skill entrypoints were found: 18 Codex and eight Agents.
- 25 entrypoints declare the same name as their directory.
- `codex/onboard-new-user/SKILL.md` declares `name: setup-codex`; this is the
  current SYS-A source state and was intentionally preserved rather than
  silently rewritten.
- `stay-on-track/scripts/score_prompt.py` passed Python AST parsing with `py`.
- `vercel-deploy/scripts/deploy.sh` passed `bash -n` using Git Bash. The default
  Windows `bash` command resolves to WSL on SYS-A, where no distribution is
  installed, so Git Bash was used for this syntax check.
