# SYS-A to SYS-B Skill Transfer

Created: 2026-08-23  
Source machine: SYS-A  
Purpose: transfer the selected exact local skill copies to SYS-B without
including publicly downloadable Matt Pocock skills or machine/account state.

## Contents

- `codex/`: 18 skill directories copied from
  `C:/Users/neela/.codex/skills/`.
- `agents/`: eight matching mirrors copied from
  `C:/Users/neela/.agents/skills/`.
- `MANIFEST.md`: scope, provenance findings, counts, and source-tree digests.
- `SHA256SUMS.txt`: one SHA-256 line for every transferred skill file.

The eight `agents/` mirrors match their corresponding `codex/` directories
byte-for-byte at the aggregate tree-digest level.

## Deliberately excluded

The following Matt Pocock/publicly downloadable skill names are not present:

- `domain-modeling`
- `grill-with-docs`
- `handoff`
- `loop-me`
- `prototype`
- `wayfinder`
- `writing-beats`
- `writing-fragments`

Also excluded:

- `.backup_20260215_192033`
- `.claude`
- `frontend-design.backup-20260322-084248`
- global `obsidian-memory-cleaner`
- global `obsidian-memory-governance`
- all `__pycache__` directories and `.pyc` files
- Codex/agent configuration, credentials, tokens, cookies, browser state,
  authentication data, databases, and plugin-cache directories

Skill-owned `agents/openai.yaml` metadata is retained where it is part of the
skill itself. No host-level configuration file is included.

## Install on SYS-B

Review the manifest and hashes before copying. Then copy the children of:

- `codex/` into SYS-B's `.codex/skills/`
- `agents/` into SYS-B's `.agents/skills/`

Do not overwrite a SYS-B skill without comparing its current copy first.
`linear` is workspace-specific and should be reviewed for the intended Linear
workspace/team before use. `vercel-deploy` contains Vercel-owned MIT material
plus SYS-A-local guardrails and should be treated as the exact SYS-A copy.

The `codex/onboard-new-user/` folder is preserved exactly from SYS-A, but its
frontmatter declares `name: setup-codex`. Decide whether SYS-B should keep that
declared invocation name or rename both the directory and metadata after
installation; the transfer archive does not silently modify it.

## Verification

From the extracted bundle root, verify `SHA256SUMS.txt` before installation.
The archive was opened after creation and every file entry was hash-compared
to the assembled bundle before handoff.
